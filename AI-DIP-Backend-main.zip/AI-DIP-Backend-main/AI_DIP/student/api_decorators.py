# decorators.py

from django.shortcuts import redirect, get_object_or_404
from internship.models import UserInternship
from django.core.exceptions import ObjectDoesNotExist
from rest_framework.response import Response
from rest_framework import status

def user_is_authenticated(view_func):
    def _wrapped_view(self, request, *args, **kwargs):
        # Check if the user is authenticated
        if request.user.is_authenticated:
            # If authenticated, call the view function
            return view_func(self, request, *args, **kwargs)
        else:
            # If not authenticated, return a forbidden response
            return redirect('login')
    return _wrapped_view

def profile_completed(view_func):
    def _wrapped_view(self, request, *args, **kwargs):
        if request.user.profile_completed:
            return view_func(self, request, *args, **kwargs)
        else:
            return Response({"detail": "Please complete your profile."}, status=status.HTTP_405_METHOD_NOT_ALLOWED)
    return _wrapped_view

def internship_started(view_func):
    def _wrapped_view(self, request, *args, **kwargs):
        try:
            user = request.user
            user_internship = UserInternship.objects.get(user = user)
            if user_internship:
                return view_func(self, request, *args, **kwargs)
            else:
                return Response({"detail": "No Internship Data Found."}, status=status.HTTP_204_NO_CONTENT)
        except ObjectDoesNotExist:
            return Response({"detail": "No Internship Data Found."}, status=status.HTTP_204_NO_CONTENT)
    return _wrapped_view