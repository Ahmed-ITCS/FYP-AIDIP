# urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.registration, name='registration'),
    path('verify/<str:token>/', views.verify_email, name='verify_email'),
    path('login/', views.loginUser, name='login'),
    path('logout/', views.logoutUser, name='logout'),
    path('home/', views.home, name='home'),
    path('profile/', views.profile, name='profile'),
    path('settings/', views.settings, name='settings'),
    path('skills', views.skills, name='skills'),
    path('internship-options/', views.internship_options, name='internship_options'),
    path('assessment-check/<int:skill>/', views.assessment_check, name='assessment_check'),
    path('assessment/<int:skill>/', views.assessment, name='assessment_test'),
    
    #path('assessment_test/', views.assessment_test, name='assessment_test'),
    # path('submit-answer/', views.submit_answer, name='submit_answer')
    
]
