from django.contrib import admin

# Register your models here.

from .models import Profile, CustomUser, Skill, UserSkill, Assessment

admin.site.register(Profile)
admin.site.register(CustomUser)
admin.site.register(Skill)
admin.site.register(UserSkill)
admin.site.register(Assessment)
