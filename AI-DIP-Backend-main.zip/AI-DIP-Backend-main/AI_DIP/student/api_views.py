# student/api_views.py

from django.shortcuts import redirect, get_object_or_404
from .utils import send_verification_email, generate_assessment, not_valid_user, evaluate_assessment
from .models import CustomUser, Profile, Assessment, Skill, UserSkill
import uuid
import json
from django.contrib.auth import authenticate, login, logout
from .api_decorators import profile_completed, user_is_authenticated
from internship.models import InternshipOption
from datetime import timedelta
from django.utils import timezone
from rest_framework.response import Response
from rest_framework.views import APIView
from internship.serializer import InternshipOptionSerializer
from .serializer import UserSkillSerializer, LoginSerializer, SkillSerializer, RegistrationSerializer, ProfileSerializer, ProfileUpdateSerializer, UserSerializer
from rest_framework import status
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.exceptions import ValidationError
from rest_framework_simplejwt.tokens import RefreshToken


class RegistrationAPIView(APIView):
    permission_classes = []

    def post(self, request):
        serializer = RegistrationSerializer(data=request.data)
        if serializer.is_valid():
            email = serializer.validated_data['email']
            if CustomUser.objects.filter(email=email).exists():
                return Response({"detail": "Email already exists. Please login."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                user = serializer.save()
                user.is_verified = False
                token = str(uuid.uuid4())
                user.email_token = token
                user.save()
                send_verification_email(user)
                return Response({"detail": "Verification email sent to your email address."}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class LoginAPIView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            username = serializer.validated_data['username']
            password = serializer.validated_data['password']
            user = authenticate(request, username=username, password=password)

        if user is not None:
            profile = Profile.objects.filter(user=user)
            if profile:
                profile = ProfileSerializer(profile.first()).data
            if not user.is_verified:
                return Response({"detail": "Email is not verified. Please verify your email."}, status=status.HTTP_400_BAD_REQUEST)
            else:
                login(request, user)
                refresh = RefreshToken.for_user(user)
                return Response({
                    'refresh': str(refresh),
                    'access': str(refresh.access_token),
                    'user': UserSerializer(user).data,
                    'profile': profile
                }, status=status.HTTP_200_OK)
        else:
            raise ValidationError({"detail": "Emails OR Passwords does not exist"})

    def get(self, request):
        if request.user.is_authenticated:
            return redirect('home_api')
        return Response({"detail": "Please provide login credentials."}, status=status.HTTP_200_OK)
    
class LogoutAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        logout(request)
        return Response({"detail": "Successfully logged out."}, status=status.HTTP_200_OK)

class VerifyEmailAPIView(APIView):
    permission_classes = []

    def get(self, token):
        try:
            user = CustomUser.objects.get(email_token=token)
            user.is_verified = True
            user.save()
            return Response({"detail": "Email verified successfully"}, status=status.HTTP_200_OK)
        except CustomUser.DoesNotExist:
            return Response({"detail": "Invalid token"}, status=status.HTTP_400_BAD_REQUEST)
        
class HomeAPIView(APIView):
    permission_classes = [IsAuthenticated]

    @user_is_authenticated
    @profile_completed
    def get(self, request):
        user = request.user
        if user.profile:
            user_serializer = UserSerializer(user)
            profile = get_object_or_404(Profile, user=user)
            profile_serializer = ProfileSerializer(profile)
            return Response({"user": user_serializer.data, "profile": profile_serializer.data}, status=status.HTTP_200_OK)
        return Response({"detail": "Profile not completed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

class ProfileAPIView(APIView):
    permission_classes = [IsAuthenticated]

    @user_is_authenticated
    def get(self, request):
        user = request.user
        if user.profile_completed:
            profile = get_object_or_404(Profile, user=user)
            serializer = ProfileSerializer(profile, context={'request': request})
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response({"detail": "Profile not completed"}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    @user_is_authenticated
    def post(self, request):
        mutable_data = request.data.copy()  # Make a mutable copy of request.data
        mutable_data['user'] = request.user.id

        serializer = ProfileSerializer(data=mutable_data)
        if serializer.is_valid():
            serializer.save(user=request.user)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class SettingsAPIView(APIView):
    permission_classes = [IsAuthenticated]

    @user_is_authenticated
    @profile_completed
    def patch(self, request):
        user = request.user
        userData = request.data.get('profileUserData')
        profile = request.data.get('profileData')
        user_serializer = UserSerializer(user, data=userData, partial=True)
        profile_serializer = ProfileUpdateSerializer(user.profile, data=profile, partial=True)
        
        if user_serializer.is_valid() and profile_serializer.is_valid():
            user_serializer.save()
            profile_serializer.save()
            return Response({"user": user_serializer.data, "profile": profile_serializer.data}, status=status.HTTP_200_OK)
        
        errors = {}
        if not user_serializer.is_valid():
            errors.update(user_serializer.errors)
        if not profile_serializer.is_valid():
            errors.update(profile_serializer.errors)
        
        return Response(errors, status=status.HTTP_400_BAD_REQUEST)

class SkillAPI(APIView):
    permission_classes = [IsAuthenticated]

    @user_is_authenticated
    @profile_completed
    def get(self, request):
        skills = Skill.objects.all()
        user_skills = UserSkill.objects.filter(user=request.user)
        for user_skill in user_skills:
            if user_skill.created_at + timedelta(days=30) > timezone.now():
                skills = skills.exclude(id=user_skill.skill.id)
        
        serializer = SkillSerializer(skills, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
class InternshipOptionsAPI(APIView):
    permission_classes = [IsAuthenticated]

    # @user_is_authenticated
    # @profile_completed
    def get(self, request):
        internship_options = InternshipOption.objects.all()
        serializer = InternshipOptionSerializer(internship_options, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
class UserSkillAPI(APIView):
    permission_classes = [IsAuthenticated]

    @user_is_authenticated
    @profile_completed
    def get(self, request):
        user_skills = UserSkill.objects.filter(user=request.user, is_passed=True)
        if user_skills:
            serializer = UserSkillSerializer(user_skills, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response({"detail": "No skills passed yet"}, status=status.HTTP_204_NO_CONTENT)
    

class AssessmentCheckAPI(APIView):
    permission_classes = [IsAuthenticated]

    @user_is_authenticated
    @profile_completed
    def get(self, request, skill):
        skill = Skill.objects.get(id = skill)
        serializer = SkillSerializer(skill, many=False)
        return Response(serializer.data, status=status.HTTP_200_OK)

class AssessmentAPI(APIView):
    permission_classes = [IsAuthenticated]

    @user_is_authenticated
    @profile_completed
    def get(self, request, skill):
        user = request.user
        skill = get_object_or_404(Skill, id=skill)
        if not_valid_user(request, skill):
            return Response({
                'messages': 'User is not valid for this skill assessment',
                'data' : {}
            }, status=status.HTTP_400_BAD_REQUEST)
        questions = generate_assessment(skill)
        assessment = Assessment.objects.filter(user=user, skill=skill).first()
        if assessment:
            assessment.attempt_count += 1
            assessment.date_of_assessment = timezone.now()
            assessment.questions = questions
            assessment.save()

            user_skill = UserSkill.objects.get(user=user, skill=skill)
            user_skill.created_at = timezone.now()
            user_skill.save()
        else:
            new_assessment = Assessment.objects.create(
                user=user,
                skill=skill,
                attempt_count=1,
                date_of_assessment=timezone.now(),
                questions=questions
            )
            user_skill = UserSkill.objects.create(
                user=user,
                skill=skill,
                assessment=new_assessment,
                created_at = timezone.now()
            )
        time = timezone.now() + timedelta(minutes=20)
        response_data = { 
            'questions' : questions,
            'time' : time
        }
        return Response(response_data, status=status.HTTP_200_OK)

    @user_is_authenticated
    @profile_completed
    def post(self, request, skill):
        user = request.user
        skill = get_object_or_404(Skill, id=skill)
        assessment = Assessment.objects.filter(user=user, skill=skill).last()
        user_skill = get_object_or_404(UserSkill, user=user, skill=skill)

        # Validate and save user answers
        data = request.data
        answers = data.get('answers', [])

        if not isinstance(answers, list):
            return Response({"detail": "Invalid answers format"}, status=status.HTTP_400_BAD_REQUEST)
        
        assessment.user_answers = answers
        assessment.save()

        score = evaluate_assessment(assessment.questions, answers)
        user_skill.score = score
        if score >= 60:
            user_skill.is_passed = True
        user_skill.save()

        user_skill_serializer = UserSkillSerializer(user_skill)
        return Response(user_skill_serializer.data, status=status.HTTP_200_OK)
