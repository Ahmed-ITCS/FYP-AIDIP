# views.py

from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from .utils import send_verification_email, generate_assessment, not_valid_user, evaluate_assessment
from .models import CustomUser, Profile, Assessment, Skill, UserSkill
import uuid
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .decorators import profile_completed, user_is_authenticated
from internship.models import InternshipOption
from datetime import timedelta
from django.utils import timezone
from rest_framework.response import Response
from rest_framework.views import APIView
from .serializer import AssessmentSerializer, UserSkillSerializer, LoginSerializer
from rest_framework import status
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.exceptions import ValidationError


def registration(request):
    if request.method == 'POST':
        mail = request.POST.get('email')
        password = request.POST.get('password')
        user = 'student'
        if CustomUser.objects.filter(email=mail).exists():
            messages.error(request, 'Email already exists. Please login.')
            return redirect('login')
        else:
            user = CustomUser.objects.create_user(username=mail, email=mail, password=password, user_type=user)
            user.is_verified = False
            token = str(uuid.uuid4())
            user.email_token = token
            user.save()
            send_verification_email(user)
            messages.error(request, 'Verification email sent to your email address.')
            return redirect('login')

    return render(request, 'student/register.html')


def verify_email(request, token):
    try:
        user = CustomUser.objects.get(email_token=token)
        user.is_verified = True
        user.save()
        return HttpResponse('Email verified successfully')
    except:
        return HttpResponse('Invalid token')

def loginUser(request):

    if request.user.is_authenticated:
        if request.user.profile_completed == False:
            return redirect('profile')
        else:
            return redirect('home')

    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)

        if user is not None:
            if user.is_verified == False:
                messages.error(request, 'Email is not verified. Please verify your email.')
                return redirect('login')
            else:
                login(request, user)
                return redirect('home')
        else:
            messages.error(request, 'Email OR Password does not exist')

    return render(request, 'student/login.html')

@login_required(login_url='login')
def logoutUser(request):
    logout(request)
    return redirect('login')

@login_required(login_url='login')
@user_is_authenticated
@profile_completed
def home(request):
    context = { 'user': request.user }
    return render(request, 'student/home.html', context)

#Get and Post Method of Profile Model
@login_required(login_url='login')
def profile(request):
    user = request.user
    if user.profile_completed == True:
        profile = Profile.objects.get(user=user)
        context = {
            'user': profile
        }
        return render(request, 'student/profile_get.html', context)
    if request.method == 'POST':
        profile_photo = request.FILES.get('profile_photo')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        phone_number = request.POST.get('phone_number')
        university_name = request.POST.get('university_name')
        department = request.POST.get('department')
        degree_name = request.POST.get('degree_name')
        graduation_year = request.POST.get('graduation_year')
        gpa = request.POST.get('gpa')
        category = request.POST.get('category')

        profile = Profile.objects.create(
            user = request.user,
            first_name = first_name,
            last_name = last_name,
            profile_photo = profile_photo,
            phone_number = phone_number,
            university_name = university_name,
            department = department,
            degree_name = degree_name,
            graduation_year = graduation_year,
            gpa = gpa,
            category = category
        )
        user.profile_completed = True
        user.save()
        return redirect('home')

    context = {
        'user': user
    }
    return render(request, 'student/profile.html', context)

#Patch method of Profile Model
@login_required(login_url='login')
@user_is_authenticated
@profile_completed
def settings(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        profile_photo = request.FILES.get('profile_photo')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        phone_number = request.POST.get('phone_number')
        university_name = request.POST.get('university_name')
        department = request.POST.get('department')
        degree_name = request.POST.get('degree_name')

        user = request.user
        user.profile.profile_photo = profile_photo
        user.username = username
        if password != '':
            user.set_password(password)
        user.profile.first_name = first_name
        user.profile.last_name = last_name
        user.profile.phone_number = phone_number
        user.profile.university_name = university_name
        user.profile.department = department
        user.profile.degree_name = degree_name
        user.save()

    return render(request, 'student/settings.html')

# @login_required(login_url='login')
# @user_is_authenticated
# @profile_completed
def skills(request):
    if request.method == 'GET':
        skills = Skill.objects.all()
        # Remove those skills which are already passesd by the user in the UserSkill model
        user_skills = UserSkill.objects.filter(user=request.user)
        for user_skill in user_skills:
            if user_skill.created_at + timedelta(days=30) > timezone.now():
                skills = skills.exclude(id=user_skill.skill.id)

        context = { 'skills': skills }
        return render(request, 'student/skills.html', context)


@login_required(login_url='login')
@user_is_authenticated
@profile_completed
def internship_options(request):
    options = InternshipOption.objects.all()
    return render(request, 'student/options.html', {'options': options})

# @login_required(login_url='login')
# @user_is_authenticated
# @profile_completed
def assessment_check(request, skill):
    if request.method == 'GET':
        skill = Skill.objects.get(id = skill)
        context = { 'skill': skill }
        return render(request, 'student/assessment_check.html', context)

@login_required(login_url='login')
@user_is_authenticated
@profile_completed
def assessment(request, skill):
    if request.method == 'GET':
        # Get the assessment if the user has already attempted it
        user = request.user
        skill = Skill.objects.get(id=skill)
        if not_valid_user(request, skill):
            return HttpResponse("404 Page not Found")
        questions = generate_assessment(skill)
        assessment = Assessment.objects.filter(user=user, skill=skill).first()
        if assessment:
            assessment.attempt_count += 1
            assessment.date_of_assessment = timezone.now()
            assessment.questions = questions
            assessment.save()

            user_skill = UserSkill.objects.get(user=user, skill=skill)
            user_skill.created_at = timezone.now()
            user_skill.save()
        else:
            new_assessment = Assessment.objects.create(
                user=user,
                skill=skill,
                attempt_count=1,
                date_of_assessment=timezone.now(),
                questions=questions
            )
            user_skill = UserSkill.objects.create(
                user=user,
                skill=skill,
                assessment=new_assessment,
                created_at = timezone.now()
            )
        time = timezone.now() + timedelta(minutes=20)
        context = { 
            'questions' : questions,
            'time' : time
        }
        return render(request, 'student/assessment_test.html', context)
    
    if request.method == 'POST':
        answers = request.POST.getlist('answer')
        user = request.user
        skill = Skill.objects.get(id=skill)
        assessment = Assessment.objects.filter(user=user, skill=skill).last()
        user_skill = UserSkill.objects.get(user=user, skill=skill)
        assessment.user_answers = answers
        assessment.save()
        score = evaluate_assessment(assessment.questions, answers)
        user_skill.score = score
        if score >= 60:
            user_skill.is_passed = True
        user_skill.save()
        
        return render(request, 'student/test.html')



    # permission_classes = [AllowAny]

    # def post(self, request):
    #     serializer = LoginSerializer(data=request.data)
    #     if serializer.is_valid(raise_exception=True):
    #         username = serializer.validated_data['username']
    #         password = serializer.validated_data['password']
    #         user = authenticate(request, username=username, password=password)

    #     if user is not None:
    #         if not user.is_verified:
    #             return Response({"detail": "Email is not verified. Please verify your email."}, status=status.HTTP_400_BAD_REQUEST)
    #         else:
    #             login(request, user)
    #             return Response({"detail": "Login successful"}, status=status.HTTP_200_OK)
    #     else:
    #         raise ValidationError({"detail": "Emails OR Passwords does not exist"})

    # def get(self, request):
    #     if request.user.is_authenticated:
    #             return redirect('home')

    #     return Response({"detail": "Please provide login credentials."}, status=status.HTTP_200_OK)


    # permission_classes = [IsAuthenticated]

    # @profile_completed
    # def get(self, request, skill):
    #     user = request.user
    #     skill = get_object_or_404(Skill, id=skill)
    #     if not_valid_user(request, skill):
    #         return Response({
    #             'status': '404 Page not Found',
    #             'messages': 'User is not valid for this skill assessment',
    #             'data' : {}
    #         })
    #     questions = generate_assessment(skill)
    #     assessment = Assessment.objects.filter(user=user, skill=skill).first()
    #     if assessment:
    #         assessment.attempt_count += 1
    #         assessment.date_of_assessment = timezone.now()
    #         assessment.questions = questions
    #         assessment.save()

    #         user_skill = UserSkill.objects.get(user=user, skill=skill)
    #         user_skill.created_at = timezone.now()
    #         user_skill.save()
    #     else:
    #         new_assessment = Assessment.objects.create(
    #             user=user,
    #             skill=skill,
    #             attempt_count=1,
    #             date_of_assessment=timezone.now(),
    #             questions=questions
    #         )
    #         user_skill = UserSkill.objects.create(
    #             user=user,
    #             skill=skill,
    #             assessment=new_assessment,
    #             created_at = timezone.now()
    #         )
    #     time = timezone.now() + timedelta(minutes=20)
    #     response_data = { 
    #         'questions' : questions,
    #         'time' : time
    #     }
    #     return Response(response_data, status=status.HTTP_200_OK)

    # @profile_completed
    # def post(self, request, skill_id):
    #     user = request.user
    #     skill = get_object_or_404(Skill, id=skill_id)
    #     assessment = Assessment.objects.filter(user=user, skill=skill).last()
    #     user_skill = get_object_or_404(UserSkill, user=user, skill=skill)

    #     # Validate and save user answers
    #     data = request.data
    #     answers = data.get('answers', [])

    #     if not isinstance(answers, list):
    #         return Response({"detail": "Invalid answers format"}, status=status.HTTP_400_BAD_REQUEST)
        
    #     assessment.user_answers = answers
    #     assessment.save()

    #     score = evaluate_assessment(assessment.questions, answers)
    #     user_skill.score = score
    #     if score >= 60:
    #         user_skill.is_passed = True
    #     user_skill.save()

    #     user_skill_serializer = UserSkillSerializer(user_skill)
    #     return Response(user_skill_serializer.data, status=status.HTTP_200_OK)


# api_key = "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"
# global response_text
# global skill
# def assessment_test(request):
#     global response_text
#     global skill
#     skill = request.GET.get('skill')

#     try:
#         # Initialize the OpenAI client
#         client = OpenAI(api_key=api_key)

#         # Define the prompt using the skill parameter
#         prompt = f"ask a question multiple question about {skill} where all could feasibly be solve in 15 minutes? just start from the task straight away and make sure you don't give solution at all after each question add ',' at the end of it "
#         # Generate a response from the OpenAI API
#         response = client.completions.create(
#             model="gpt-3.5-turbo-instruct-0914",
#             prompt=prompt,
#             temperature=1,
#             top_p=1,
#             frequency_penalty=0,
#             presence_penalty=0,
#             max_tokens=500
#         )

#         # Get the text of the response
#         response_text = response.choices[0].text.strip()
#         response_text = response_text.split('\n')
#         #for dubugging print(response_text)
#     except OpenAIError as e:
#         # Handle API errors
#         response_text = f"An error occurred: {e}"

#     # Render the assessment_test.html template and pass the skill and response_text to it
#     return render(request, 'student/assessment_test.html', {'skill': skill, 'response_text': response_text})

# def are_app_keys_empty(app_names, dictionary):
#     """
#     Check if all keys corresponding to app names are empty in the dictionary.

#     Parameters:
#         app_names (list): List of app names to check.
#         dictionary (dict): The dictionary to check.

#     Returns:
#         bool: True if all keys corresponding to app names are empty, False otherwise.
#     """
#     for app_name in app_names:
#         if app_name in dictionary and dictionary[app_name]:
#             return False
#     return True

# def extract_numeric_value(sentence):
#     # Define a regular expression pattern to match numeric values
#     pattern = r'\b\d+(\.\d+)?\b'  # This pattern matches integers and floating-point numbers
    
#     # Search for the pattern in the sentence
#     match = re.search(pattern, sentence)
    
#     if match:
#         # Extract the matched value
#         numeric_value = match.group()
#         return numeric_value
#     else:
#         return None

# global score 
# def submit_answer(request):
#     global response_text
#     global skill
#     global score
    
#     if request.method == 'POST':
#         # Get the submitted answer from the form
#         #answer = request.POST.get('answer')
#         answer = {}
#         keys =[]
#         for key, value in request.POST.items():
#             if key.startswith('answer'):
#                 answer[key] = value
#                 keys.append(key)
#         #print('response_text',response_text)
#         #print("answer",answer)
#         if are_app_keys_empty(keys,answer):
#             # If the answer is empty, set a specific response and render the result page
#             ##print("HIP HIP HIP")
#             create_or_update_assessment(request, skill, response_text, answer)  
#             response_text = "TIMES UP"
#             return render(request, 'student/assessment_result.html', {'skill': skill, 'response_text': response_text})
        
#         try:
#             ##print("HOP HOP HOP")
#             # Initialize the OpenAI client
#             client = OpenAI(api_key=api_key)

#             # Define the prompt using the skill parameter
#             prompt = f"this is basically a quiz where I am assesing a student, Question are {response_text} and they are generated by you , it's answer given by student are {answer}, according to the answer give me a score and please rate it out of 100, give me 1 score for them all"
#             print("\n\n\n",prompt,"\n\n\n\n\n")
            
#             # Generate a response from the OpenAI API
#             response = client.completions.create(
#                 model="gpt-3.5-turbo-instruct-0914",
#                 prompt=prompt,
#                 temperature=1,
#                 top_p=1,
#                 frequency_penalty=0,
#                 presence_penalty=0,
#                 max_tokens=1000
#             )
#             # Get the text of the response
#             response_textt = response.choices[0].text.strip()
#             score = extract_numeric_value(response_textt)
#             create_or_update_assessment(request, skill, response_text, answer,score)
#             #response_textt = response.choices[0].text.strip()
#             print(response_textt)
#             print("Response Text:", response_textt) 
            
#             return render(request, 'student/assessment_result.html', {'skill': skill, 'response_text': score})

#         except OpenAIError as e:
#             # Handle API errors
#             response_text = f"An error occurred: {e}"
#             return HttpResponse(response_text)
#     else:
#         # Handle GET requests (if applicable)
#         return HttpResponse('Method not allowed!')

# def create_or_update_assessment(request, skill, response_text, answer,score):
#     score = int(score)
#     # Check if an assessment already exists for the user with the same skill name
#     user_assessment = Assessment.objects.filter(profile=request.user.profile, skill_name=skill).first()
#     new_assessment = None
#     if user_assessment:
#         # If assessment exists, increment the attempt number
#         user_assessment.attempt_number += 1
#         user_assessment.save()
#     else:
#         # If assessment doesn't exist, create a new entry
#         if not score >= 60:
#             user_profile = request.user.profile
#             new_assessment = Assessment.objects.create(
#             profile=user_profile,
#             skill_name=skill,
#             attempt_number=1,
#             SkillStatus="Pass",  # Comma added here
#             date_of_assessment=timezone.now(),
#             time_of_completion=timezone.now()
#         )
#         else:
#             user_profile = request.user.profile
#             new_assessment = Assessment.objects.create(
#                 profile=user_profile,
#                 skill_name=skill,
#                 attempt_number=1,
#                 SkillStatus="FAIL",  # Comma added here
#                 date_of_assessment=timezone.now(),
#                 time_of_completion=timezone.now()
#             )

#     # Save attempts
#     if answer:
#         attempt = Attempt.objects.create(
#             assessment=new_assessment if new_assessment else user_assessment,
#             question=response_text,
#             answer=answer.values()
#         )
#     elif answer is None or not answer:  # If answer is None or an empty dictionary
#         for i, question in enumerate(response_text): 
#         # Loop over the response_text list
#             attempt = Attempt.objects.create(
#             assessment=new_assessment if new_assessment else user_assessment,  # Use new_assessment if available, otherwise user_assessment
#             question=response_text,  
#             answer=answer.values()
#         )

