# utils.py

from django.conf import settings
from django.core.mail import send_mail
from .models import UserSkill
from datetime import timedelta
from django.utils import timezone

def send_verification_email(user):
    try:
        subject = 'Email Verification'
        message = f'Hi {user.username},\n\nPlease click on the link below to verify your email.\n\nhttp://{settings.DOMAIN}/verify/{user.email_token}/'
        email_from = settings.EMAIL_HOST_USER
        recipient_list = [user.email]
        send_mail(subject, message, email_from, recipient_list)
        print(email_from, recipient_list, message)

    except Exception as e:
        print("Error occurred while sending email:", e)
        return False
    
    return True

def not_valid_user(request, skill):
    user_skill = UserSkill.objects.filter(user=request.user, skill_id=skill.id)
    if user_skill:
        for skill in user_skill:
            if skill.created_at + timedelta(days=30) > timezone.now():
                return True
    return False

def generate_assessment(skill):
    questions = {
        "Question1" : "Question no. 1: This is qbout the question no 1?",
        "Question2" : "Question no. 2: This is qbout the question no 2?",
        "Question3" : "Question no. 3: This is qbout the question no 3?",
        "Question4" : "Question no. 4: This is qbout the question no 4?",
        "Question5" : "Question no. 5: This is qbout the question no 5?"
    }
    return questions

def evaluate_assessment(questions, answers):
    score = 50
    
    return score
