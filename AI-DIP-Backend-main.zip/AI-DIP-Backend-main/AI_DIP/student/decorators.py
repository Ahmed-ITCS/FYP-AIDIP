# decorators.py

from django.shortcuts import redirect, get_object_or_404
from internship.models import UserInternship
from django.core.exceptions import ObjectDoesNotExist


def user_is_authenticated(view_func):
    def _wrapped_view(request, *args, **kwargs):
        # Check if the user is authenticated
        if request.user.is_authenticated:
            # If authenticated, call the view function
            return view_func(request, *args, **kwargs)
        else:
            # If not authenticated, return a forbidden response
            return redirect('login')
    return _wrapped_view

def profile_completed(view_func):
    def _wrapped_view(request, *args, **kwargs):
        if request.user.profile_completed:
            return view_func(request, *args, **kwargs)
        else:
            return redirect('profile')
    return _wrapped_view

def internship_started(view_func):
    def _wrapped_view(request, *args, **kwargs):
        try:
            user = request.user
            user_internship = UserInternship.objects.get(user = user)
            if user_internship:
                return view_func(request, *args, **kwargs)
            else:
                return redirect('internship_options')
        except ObjectDoesNotExist:
            return redirect('internship_options')
    return _wrapped_view

def user_student(view_func):
    def _wrapped_view(request, *args, **kwargs):
        if request.user.user_type == 'student':
            return view_func(request, *args, **kwargs)
        else:
            return redirect('home-org')
    return _wrapped_view

def user_organization(view_func):
    def _wrapped_view(request, *args, **kwargs):
        if request.user.user_type == 'organization':
            return view_func(request, *args, **kwargs)
        else:
            return redirect('home')
    return _wrapped_view