from django.urls import path
from student.api_views import AssessmentAPI, LoginAPIView, SkillAPI, InternshipOptionsAPI, AssessmentCheckAPI, VerifyEmailAPIView, RegistrationAPIView, ProfileAPIView, SettingsAPIView, HomeAPIView, LogoutAPIView, UserSkillAPI
from internship.api_views import ApplyForInternshipAPIView, TaskAPIView, SubmissionAPIView, SubmissionSuccessAPIView, TaskEvaluationAPIView, OptionStackAPIView, InternshipStatusAPIView
from ai_manager.api_views import ManagerAPIView

urlpatterns = [
    #Student API URLs
    path('login/', LoginAPIView.as_view(), name='login_api'),
    path('verify/<str:token>/', VerifyEmailAPIView.as_view(), name='verify_email_api'),
    path('register/', RegistrationAPIView.as_view(), name='registration_api'),
    path('logout/', LogoutAPIView.as_view(), name='logout_api'),
    path('home/', HomeAPIView.as_view(), name='home_api'),
    path('profile/', ProfileAPIView.as_view(), name='profile_api'),
    path('settings/', SettingsAPIView.as_view(), name='settings_api'),
    path('skills/', SkillAPI.as_view(), name='skills_api'),
    path('user-skills/', UserSkillAPI.as_view(), name='user_skills_api'),
    path('internship-options/', InternshipOptionsAPI.as_view(), name='internship_options_api'),
    path('assessment-check/<int:skill>/', AssessmentCheckAPI.as_view(), name='assessment_check'),
    path('assessment/<int:skill>/', AssessmentAPI.as_view(), name='assessment'),

    #Internship API URLs
    path('internship/apply/<int:id>/', ApplyForInternshipAPIView.as_view(), name='apply_for_internship_api'),
    path('internship/task/', TaskAPIView.as_view(), name='task_api'),
    path('internship/status/', InternshipStatusAPIView.as_view(), name='internship_status_api'),
    path('internship/submission/<int:task_id>/', SubmissionAPIView.as_view(), name='submission_api'),
    path('internship/submission-success/', SubmissionSuccessAPIView.as_view(), name='submission_success_api'),
    path('internship/task-evaluation/<int:task_id>/', TaskEvaluationAPIView.as_view(), name='task_evaluation_api'),
    path('internship/option-stack/<str:title>/', OptionStackAPIView.as_view(), name='option_stack_api'),

    #AI-Manager API URLs
    path('manager/', ManagerAPIView.as_view(), name='manager_api'),

    #Organization API URLs
    
]
