import unittest
from unittest.mock import Mock

from utils import check_skills
from models import UserSkill

class TestCheckSkills(unittest.TestCase):
    def test_check_skills_with_matching_skills(self):
        user = Mock()
        internship_option = Mock()
        internship_option.technology_stack = "Python, Django, SQL"
        user_skills = Mock()
        user_skills.filter.return_value.exists.return_value = True
        UserSkill.objects.filter.return_value = user_skills

        result = check_skills(user, internship_option)

        self.assertTrue(result)

    def test_check_skills_with_missing_skills(self):
        user = Mock()
        internship_option = Mock()
        internship_option.technology_stack = "Python, Django, SQL"
        user_skills = Mock()
        user_skills.filter.return_value.exists.return_value = False
        UserSkill.objects.filter.return_value = user_skills

        result = check_skills(user, internship_option)

        self.assertFalse(result)

if __name__ == '__main__':
    unittest.main()