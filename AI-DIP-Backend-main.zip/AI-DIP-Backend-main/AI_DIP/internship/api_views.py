#internship/api_views.py

from .utils import check_skills, submit_task
from student.api_decorators import profile_completed, user_is_authenticated, internship_started
from django.shortcuts import get_object_or_404
from datetime import timedelta
from django.utils import timezone
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
from django.shortcuts import get_object_or_404
from django.utils import timezone
from .models import InternshipOption, UserInternship, InternshipTask, CodeSubmission
from .serializer import UserInternshipSerializer, InternshipTaskSerializer, CodeSubmissionSerializer, InternshipOptionSerializer
from .utils import check_skills, generate_task, evaluate_task 

class ApplyForInternshipAPIView(APIView):
    permission_classes = [IsAuthenticated]

    @user_is_authenticated
    @profile_completed
    def post(self, request, id):
        user = request.user
        option = get_object_or_404(InternshipOption, pk=id)
        user_internship = UserInternship.objects.filter(user=user, internship_option=option).first()
        incomplete_internship = UserInternship.objects.filter(user=user, is_completed=False).first()
        if incomplete_internship:
            return Response({"detail": "You have an incomplete internship."}, status=status.HTTP_207_MULTI_STATUS)
        if user_internship:
            return Response({"detail": "Already applied for this internship."}, status=status.HTTP_208_ALREADY_REPORTED)
        if check_skills(user, option):
            user_internship = UserInternship.objects.create(user=user, internship_option=option)
            generate_task(user_internship, option)
            return Response(UserInternshipSerializer(user_internship).data, status=status.HTTP_201_CREATED)
        else:
            return Response({"detail": "User does not have the required skills."}, status=status.HTTP_204_NO_CONTENT)
        
class InternshipStatusAPIView(APIView):
    permission_classes = [IsAuthenticated]

    @user_is_authenticated
    @profile_completed
    def get(self, request):
        user = request.user
        user_internship = UserInternship.objects.filter(user=user, is_completed=False).first()
        if user_internship:
            #count the total completed tasks of that internship
            total_tasks = InternshipTask.objects.filter(internship_option=user_internship.internship_option, task_completed=True).count()
            if total_tasks < 1:
                return Response(
                    {"status": "In Progress", "tasks_completed": total_tasks, "total_tasks": 1, "progress": 1},
                    status=status.HTTP_200_OK
                )
            else:
                progress = total_tasks * 10
                return Response(
                    {"status": "In Progress", "tasks_completed": total_tasks, "total_tasks": total_tasks, "progress": progress},
                    status=status.HTTP_200_OK
                )
        return Response({"detail": "No internship found.", "progress": 0}, status=status.HTTP_204_NO_CONTENT)

class TaskAPIView(APIView):
    permission_classes = [IsAuthenticated]

    @user_is_authenticated
    @profile_completed
    @internship_started
    def get(self, request):
        user = request.user
        user_internship = get_object_or_404(UserInternship, user=user, is_completed=False)
        task = InternshipTask.objects.filter(internship_option=user_internship.internship_option)
        # if not task:
        #     option = user_internship.internship_option
        #     task = generate_task(user_internship, option)
        serializer = InternshipTaskSerializer(task, many=True)  # Serialize queryset as a list
        return Response(serializer.data)

class SubmissionAPIView(APIView):
    permission_classes = [IsAuthenticated]

    @user_is_authenticated
    @profile_completed
    @internship_started
    def post(self, request, task_id):
        user = request.user
        internship_task = get_object_or_404(InternshipTask, pk=task_id)
        current_date = timezone.now()
        update_count = 0
        data = request.data
        file_names = data.get('fileLabel', [])
        codes = data.get('fileCode', [])
        # file_names = request.data.get('fileLabel', [])
        # codes = request.data.get('fileCode', [])

        for file_name, code in zip(file_names, codes):
            submission, created = CodeSubmission.objects.update_or_create(
                user=user, internship_task=internship_task, file_name=file_name,
                defaults={'code': code}
            )
            if not created:
                update_count += 1

        internship_task.submission_status = True
        if current_date > internship_task.submission_deadline:
            internship_task.is_late_submission = True

        if update_count:
            if internship_task.submission_deadline - current_date < timedelta(hours=4):
                hr = 4
                internship_task.submission_deadline = timezone.now() + timedelta(hours=hr)
        evaluate_task(internship_task)
        internship_task.save()
        return Response({"detail": "Submission successful."}, status=status.HTTP_200_OK)

class SubmissionSuccessAPIView(APIView):
    permission_classes = [IsAuthenticated]

    @user_is_authenticated
    @profile_completed
    @internship_started
    def get(self, request):
        return Response({"detail": "Submission successful."})

class TaskEvaluationAPIView(APIView):
    permission_classes = [IsAuthenticated]

    @user_is_authenticated
    @profile_completed
    @internship_started
    def get(self, request, task_id):
        internship_task = get_object_or_404(InternshipTask, pk=task_id)
        return Response(InternshipTaskSerializer(internship_task).data)

class OptionStackAPIView(APIView):
    permission_classes = [IsAuthenticated]

    @user_is_authenticated
    @profile_completed
    def get(self, request, title):
        options = InternshipOption.objects.filter(title=title)
        return Response(InternshipOptionSerializer(options, many=True).data)

    @user_is_authenticated
    @profile_completed
    def post(self, request, title):
        option_id = request.data.get('stack')
        return Response({"redirect_to": f"/apply/{option_id}/"}, status=status.HTTP_302_FOUND)
