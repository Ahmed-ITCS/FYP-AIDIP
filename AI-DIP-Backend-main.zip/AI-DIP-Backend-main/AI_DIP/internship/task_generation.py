# # internship/task_generation.py

# import openai
# from datetime import datetime, timedelta
# from .models import InternshipTask

# class TaskGenerator:
#     def __init__(self):
#         self.openai_api_key = 'your-api-key'
#         openai.api_key = self.openai_api_key

#     def generate_task(self, title, description, deadline_days):
#         # Generate task details using OpenAI API
#         task_details = openai.Completion.create(
#             engine="text-davinci-003",
#             prompt=f"Task Title: {title}\n\nDescription: {description}",
#             max_tokens=200
#         )
#         # Extract generated task description
#         generated_task_description = task_details.choices[0].text.strip()
#         # Calculate submission deadline
#         submission_deadline = datetime.now() + timedelta(days=deadline_days)
#         # Save generated task to the database
#         task = InternshipTask.objects.create(
#             title=title,
#             description=generated_task_description,
#             submission_deadline=submission_deadline
#         )
#         return task
