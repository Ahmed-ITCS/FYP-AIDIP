# urls.py

from django.urls import path
from . import views

urlpatterns = [
    #path('internship-options/', views.internship_options, name='internship_option'),
    path('apply/<str:id>/', views.apply_for_internship, name=('apply')),
    path('option-stack/<str:title>/', views.option_stack, name='option-stack'),
    path('tasks/', views.task, name = "task"),

    path('submission/<str:task_id>/', views.submission, name='submission'),
    path('submission-success/', views.submission_success, name='submission-success'),
    path('task-evaluation/<str:task_id>/', views.task_evaluation, name='task-evaluation'),
    
]
