# internship/utils.py

from student.models import UserSkill
from .models import InternshipTask, CodeSubmission
from django.http import HttpResponse
from openai import OpenAI
from datetime import datetime, timedelta
from django.utils import timezone
from django.conf import settings
TOTAL_TASKS = 10

def check_skills(user, internship_option):
    required_skills = internship_option.required_skills.all()
    user_skills = UserSkill.objects.filter(user=user, is_passed=True)
    for skill in required_skills:
        if not user_skills.filter(skill=skill).exists() and skill != 'Templates':
            return False
    return True

def submit_task(user_internship, solution, submission_date):
    user_internship.solution = solution
    if submission_date > user_internship.internship_task.submission_deadline:
        user_internship.is_late_submission = True
    user_internship.submission_date = submission_date
    user_internship.save()

def generate_task(user_internship, option):
    try:
        client = OpenAI(api_key=settings.OPENAI_API_KEY)
        skills = user_internship.internship_option.required_skills.all()
        skills = [skill.skill_name for skill in skills]
        print(skills)
        prompt = f""" You are an AI assistant tasked with generating a real-world coding project for an internship in the role of 
        {user_internship.internship_option.title} under these skills {skills}.
        The project should meet the following requirements: 
            1. **Relevance**: The project should be a practical and common task that a {user_internship.internship_option.title} intern
                would typically encounter during an actual internship.
            2. **Scope**: The project should be challenging enough to be completed within a 2-day deadline, assuming the intern works 
                for 4 hours per day (totaling 8 hours of work).
            3. **Engaging**: The project should be interesting and engaging, allowing the intern to apply their skills in a real-world 
                scenario while learning new concepts or techniques.
            4. **Realistic**: The project should simulate a real-world situation that a {user_internship.internship_option.title} might 
                face in a professional setting, such as building a feature for an existing application or creating a proof-of-concept for a new idea.
            5. **Clarity**: The project description should be clear, concise, and well-structured, providing all the necessary information
                and requirements for the intern to understand and complete the task successfully. 
            6. **Evaluation**: The project should be designed in a way that allows for objective evaluation of the intern's work, such as
                specific functional requirements, test cases, or acceptance criteria.
        Please generate a detailed project description that meets the above requirements, including a brief introduction, clear objectives, 
        specific requirements or user stories, and any additional resources or constraints that the intern should be aware of."""
        response = client.completions.create(
            model="gpt-3.5-turbo-instruct-0914",
            prompt=prompt,
            temperature=1,
            top_p=1,
            frequency_penalty=0,
            presence_penalty=0,
            max_tokens=500
        )
        task_description = response.choices[0].text.strip()
        task_description = task_description.split('\n')
        
        new_task = InternshipTask.objects.create(internship_option=option , title="Complete The Project", description=task_description, submission_deadline=datetime.now() + timedelta(days=1))
        user_internship.internship_task = new_task
        user_internship.internship_option = option
        user_internship.save()
        return new_task
    
    except Exception as e:
        print(f"Error generating task: {str(e)}")

def evaluate_task(internship_task):
    try:
        client = OpenAI(api_key=settings.OPENAI_API_KEY)
        solution = CodeSubmission.objects.filter(internship_task=internship_task)
        internship_task.issues = None
        internship_task.is_evaluated = False
        while(internship_task.issues == None and internship_task.is_evaluated == False):
            prompt = f"""
            You are an AI assistant tasked with evaluating a coding solution submitted by an intern for the role of 
            {internship_task.title}. The task description is as follows: \n {internship_task.description}. 
            The intern has submitted the following solution: [{solution}]. 
            Before proceeding with the evaluation, you must first validate that the submitted solution is a valid attempt
            at solving the given task and contains actual code related to the task requirements. 
            'Use the word issue in reult of the evaluation or in the response of this prompt if solution does not fulfill the requirements'.
            if you found any case from these 3 cases or others then Highlight or mention the word 'issue' in the response of this propmt.
            Do not proceed with the evaluation if the submitted solution meets any of the following conditions:
                1. The solution contains only dummy text (e.g., Lorem Ipsum) or irrelevant content unrelated to the task.
                2. The solution does not include any code files (e.g., HTML, CSS, JavaScript) or the code files are completely empty.
                3. The code in the solution is clearly copied from an external source and does not appear to be the intern's original work.
            If any of the above conditions are met, clearly indicate that the solution is invalid and cannot be evaluated. 
            Provide a brief explanation for why the solution is considered invalid.
            If the submitted solution does not meet any of the above conditions and appears to be a genuine attempt at solving the 
            task, proceed with the comprehensive evaluation as follows: \n Now do a comprehensive evaluation of the intern's work, 
            covering the following aspects:
                1. **Functionality**: Assess whether the solution meets all the functional requirements and user stories specified 
                    in the task description. If any requirements are not met, clearly identify them as issues.
                2. **Code Quality**: Evaluate the quality of the code, including readability, maintainability, and adherence to 
                    best practices for the specified technology stack. Highlight any areas for improvement or potential issues.
                3. **Performance**: If applicable, analyze the performance of the solution, particularly in terms of efficiency, 
                    scalability, and responsiveness. Identify any performance bottlenecks or areas that could be optimized.
                4. **Error Handling**: Examine how the solution handles errors and edge cases. Ensure that appropriate error handling 
                    mechanisms are in place and that the solution gracefully handles unexpected inputs or situations.
                5. **Documentation**: Assess the quality and completeness of any accompanying documentation, such as code comments, 
                    README files, or other supporting materials.
                6. **Testing**: If applicable, review the test cases provided by the intern and their coverage of the solution's functionality. 
                    Suggest additional tests or improvements to the testing approach if necessary.
            For each aspect, provide specific feedback and recommendations for improvement. 
            If you identify any issues, clearly highlight them using the word 'issue' and provide detailed explanations or examples.
            Additionally, assign an overall score or rating to the intern's solution based on the evaluation criteria you deem appropriate.
            Remember, the goal of this evaluation is to provide constructive feedback to help the intern enhance their skills and gain 
            practical experience in a professional setting. Be thorough, fair, and objective in your assessment."""
            response = client.completions.create(
                model="gpt-3.5-turbo-instruct-0914",
                prompt=prompt,
                temperature=0.2,
                top_p=0.1,
                frequency_penalty=0
            )
            evaluation = response.choices[0].text.strip()
            if "issues" or "error" or "problem" or "improvement" or "issue" or "Issues" or "Issue" in evaluation:
                internship_task.issues = evaluation
                internship_task.submission_deadline = timezone.now() + timedelta(days=1)
                internship_task.title = "Fix Issues"
            else:
                internship_task.is_evaluated = True
                internship_task.task_completed = True
            if internship_task.issues != None or internship_task.is_evaluated == True:
                internship_task.save()
                return evaluation
    except Exception as e:
        print(f"Error in task Evaluation: {str(e)}")


def complete_internship(user_internship):
    three_months_ago = datetime.now() - timedelta(days=90)
    if user_internship.start_date < three_months_ago and user_internship.tasks_completed >= TOTAL_TASKS and user_internship.is_evaluated and not user_internship.issues:
        user_internship.is_completed = True
        user_internship.save()