from django.contrib import admin

# Register your models here.

from .models import InternshipOption, InternshipTask, UserInternship

admin.site.register(InternshipOption)
admin.site.register(InternshipTask)
admin.site.register(UserInternship)