# internship/views.py

from .utils import check_skills, submit_task
from django.contrib.auth.decorators import login_required
from student.decorators import profile_completed, user_is_authenticated, internship_started
from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from .models import UserInternship, InternshipOption, CodeSubmission
from .utils import *
from datetime import datetime
from django.utils import timezone

@login_required
@user_is_authenticated
@profile_completed
def apply_for_internship(request, id):
    user = request.user
    option = get_object_or_404(InternshipOption, pk=id)
    user_internship = UserInternship.objects.filter(internship_option = option)
    if user_internship:
        return redirect('task')
    if check_skills(user, option):
        # The user has the required skills, so create a new UserInternship
        user_internship = UserInternship.objects.create(user=user, internship_option=option)
        # Generate the first task for the internship
        generate_task(user_internship, option)
        return render(request, 'internship/applied.html', {'user_internship': user_internship})
    else:
        # The user doesn't have the required skills
        return render(request, 'internship/not_qualified.html', {'option': option})
    
@login_required
@user_is_authenticated
@profile_completed
@internship_started
def task(request):
    user = request.user
    user_internship = UserInternship.objects.get(user = user)
    task = InternshipTask.objects.get(internship_option = user_internship.internship_option, task_completed = False)
    if task.task_completed:
        option = task.internship_option
        task = generate_task(user_internship, option)
    context = {'task': task,}
    return render(request, 'internship/tasks.html', context)

@login_required
@user_is_authenticated
@profile_completed
@internship_started
def submission(request, task_id):
    if request.method == 'POST':
        file_names = request.POST.getlist('fileLabel')
        codes = request.POST.getlist('fileCode')
        user = request.user
        internship_task = get_object_or_404(InternshipTask, pk=task_id)
        current_date = timezone.now()
        update_count = 0
        # Iterate over the files and save each one
        for file_name, code in zip(file_names, codes):
            submission = CodeSubmission.objects.filter(user=user, internship_task=internship_task, file_name=file_name)
            if submission:
                submission.update(code=code)
                internship_task.issues = None
                update_count = update_count + 1
            else:
                CodeSubmission.objects.create(
                    user=user, 
                    internship_task=internship_task, 
                    file_name=file_name, 
                    code=code
                )

        internship_task.submission_status = True
        if current_date > internship_task.submission_deadline:
            internship_task.is_late_submission = True

        if update_count:
            hr = update_count * 4
            internship_task.submission_deadline = datetime.now() + timedelta(hours=hr)
        
        res = evaluate_task(internship_task)
        internship_task.save()
        return redirect('submission-success')
    return render(request, 'internship/submission.html')

@login_required
@user_is_authenticated
@profile_completed
@internship_started
def submission_success(request):
    return render(request, 'internship/submitted.html')

@login_required
@user_is_authenticated
@profile_completed
@internship_started
def task_evaluation(request, task_id):
    internship_task = get_object_or_404(InternshipTask, pk=task_id)
    return render(request, 'internship/task-evaluation.html', {'task': internship_task})

@login_required
@user_is_authenticated
@profile_completed
def option_stack(request, title):
    if request.method == 'POST':
        print("\n\n\nrequest",request,"\n\n\n")

        print("\n\n\ntitle",title,"\n\n\n")
        option_id = request.POST.get('stack')
        print("id--",option_id)
        return redirect('apply', id=option_id)
    

    options = InternshipOption.objects.filter(title=title)
    for option in options:
        for skill in option.required_skills.all():
            print(skill.skill_name)
    context = {
        'options': options,
        'title': title
    }
    return render(request, 'internship/option_stack.html', context)

# @login_required
# @user_is_authenticated
# @profile_completed
# def submit_solution(request, user_internship_id):
#     user_internship = get_object_or_404(UserInternship, pk=user_internship_id)
#     solution = request.POST['solution']
#     submit_task(user_internship, solution, datetime.now())
#     if user_internship.is_evaluated and not user_internship.issues:
#         # The solution was accepted, so generate a new task
#         generate_task(user_internship)
#     return render(request, 'internship/submitted.html', {'user_internship': user_internship})

# @login_required
# @user_is_authenticated
# @profile_completed
# def check_completion(request, user_internship_id):
#     user_internship = get_object_or_404(UserInternship, pk=user_internship_id)
#     complete_internship(user_internship)
#     return render(request, 'internship/status.html', {'user_internship': user_internship})

# def internship_tasks(request, option_id):
#     option = InternshipOption.objects.get(pk=option_id)
#     tasks = option.internshiptask_set.all()
#     return render(request, 'internship/tasks.html', {'option': option, 'tasks': tasks})

