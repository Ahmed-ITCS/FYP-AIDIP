# internship/models.py

from django.db import models
from student.models import CustomUser, Skill

class InternshipOption(models.Model):
    title = models.CharField(max_length=100)
    required_skills = models.ManyToManyField(Skill, related_name='internship_options')

    def __str__(self):
        return self.title

class InternshipTask(models.Model):
    internship_option = models.ForeignKey(InternshipOption, on_delete=models.CASCADE)
    title = models.CharField(max_length=100)
    description = models.TextField(max_length=10000)
    solution = models.TextField(null=True)
    submission_deadline = models.DateTimeField()
    is_evaluated = models.BooleanField(default=False)
    issues = models.TextField(null=True, max_length=10000)
    submission_status = models.BooleanField(default=False)
    is_late_submission = models.BooleanField(default=False)
    task_completed = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.title} - {self.description}"

    
class UserInternship(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    internship_option = models.ForeignKey(InternshipOption, on_delete=models.CASCADE)
    internship_task = models.ForeignKey(InternshipTask, on_delete=models.CASCADE, null=True)
    start_date = models.DateTimeField(auto_now_add=True)
    tasks_completed = models.PositiveIntegerField(default=0)
    late_submissions = models.PositiveIntegerField(default=0)
    is_completed = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.user.username} - {self.internship_option.title}"
    
class CodeSubmission(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    internship_task = models.ForeignKey(InternshipTask, on_delete=models.CASCADE)
    file_name = models.CharField(max_length=100)
    code = models.TextField()
    submission = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"File Name: {self.file_name} \\n Solution Code:[\\n {self.code}]\\n\\n"