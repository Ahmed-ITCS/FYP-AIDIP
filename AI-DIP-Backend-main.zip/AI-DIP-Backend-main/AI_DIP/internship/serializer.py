from rest_framework import serializers
from student.serializer import SkillSerializer
from .models import UserInternship, InternshipTask, CodeSubmission, InternshipOption, Skill

class SkillSerializer(serializers.ModelSerializer):
    class Meta:
        model = Skill
        fields = ['id', 'skill_name', 'skill_description', 'skill_category']

class InternshipOptionSerializer(serializers.ModelSerializer):
    required_skills = SkillSerializer(many=True)

    class Meta:
        model = InternshipOption
        fields = ['id', 'title', 'required_skills']

class UserInternshipSerializer(serializers.ModelSerializer):
    internship_option = InternshipOptionSerializer()

    class Meta:
        model = UserInternship
        fields = ['id', 'user', 'internship_option']

class InternshipTaskSerializer(serializers.ModelSerializer):
    class Meta:
        model = InternshipTask
        fields = '__all__'

class CodeSubmissionSerializer(serializers.ModelSerializer):
    class Meta:
        model = CodeSubmission
        fields = ['id', 'user', 'internship_task', 'file_name', 'code']
