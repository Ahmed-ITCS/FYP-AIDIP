$(document).ready(function() {
  $('form').ajaxForm();
});
