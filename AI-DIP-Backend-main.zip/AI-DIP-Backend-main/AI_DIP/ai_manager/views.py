# ai_manager/views.py

from django.shortcuts import render, redirect, HttpResponse
from .forms import ConversationForm
from .models import Conversation
from .utils import chat
from django.contrib.auth.decorators import login_required
from student.decorators import profile_completed, user_is_authenticated, internship_started
from internship.models import InternshipTask, UserInternship

@login_required
@user_is_authenticated
@profile_completed
@internship_started
def manager(request):
    user = request.user
    user_internship = UserInternship.objects.get(user=user)
    internship_task = InternshipTask.objects.get(internship_option=user_internship.internship_option, task_completed=False)
    form = ConversationForm(request.POST or None)
    conversations = Conversation.objects.all().filter(user = user, internship_task = internship_task).order_by('created_at')
    #return HttpResponse(conversations)

    if request.method == 'POST' and form.is_valid():
        user_message = form.cleaned_data['message']
        conv = chat(user, user_message, conversations, internship_task)
        return redirect('manager')

    return render(request, 'ai_manager/manager.html', {'form': form, 'conversations': conversations})
