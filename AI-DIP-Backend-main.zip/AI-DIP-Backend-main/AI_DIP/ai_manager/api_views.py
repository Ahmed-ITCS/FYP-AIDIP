from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
from django.shortcuts import get_object_or_404
from .models import Conversation
from .serializers import ConversationSerializer, ConversationFormSerializer
from .utils import chat
from internship.models import InternshipTask, UserInternship
from student.api_decorators import profile_completed, user_is_authenticated, internship_started

class ManagerAPIView(APIView):
    permission_classes = [IsAuthenticated]

    @user_is_authenticated
    @profile_completed
    @internship_started
    def get(self, request):
        user = request.user
        user_internship = get_object_or_404(UserInternship, user=user)
        internship_task = get_object_or_404(InternshipTask, internship_option=user_internship.internship_option, task_completed=False)
        conversations = Conversation.objects.filter(user=user, internship_task=internship_task).order_by('created_at')
        serializer = ConversationSerializer(conversations, many=True)
        return Response(serializer.data)

    @user_is_authenticated
    @profile_completed
    @internship_started
    def post(self, request):
        serializer = ConversationFormSerializer(data=request.data)
        if serializer.is_valid():
            user_message = serializer.validated_data['message']
            user = request.user
            user_internship = get_object_or_404(UserInternship, user=user)
            internship_task = get_object_or_404(InternshipTask, internship_option=user_internship.internship_option, task_completed=False)
            conversations = Conversation.objects.filter(user=user, internship_task=internship_task).order_by('created_at')
            conversation = chat(user, user_message, conversations, internship_task)
            serializer = ConversationSerializer(conversation, many=False)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
