# ai_manager/forms.py

from django import forms

class ConversationForm(forms.Form):
    message = forms.CharField(widget=forms.Textarea(attrs={'rows': 3}))
