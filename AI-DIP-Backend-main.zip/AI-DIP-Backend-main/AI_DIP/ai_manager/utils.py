# ai_manager/utils.py

from openai import OpenAI
from django.conf import settings
from .models import Conversation


def chat(user, user_message, coversations, internship_task):
    try:
        client = OpenAI(api_key=settings.OPENAI_API_KEY)    
        prompt = f"I am creating a chatbot for my application where students are doing internship and solving real world problems tasks. During the internship they can seek help from the AI-Manager to undersatnd the task only. They can ask question from chatbot based AI-Manager if the student face any ambiguity in the task description. You are not allowed to provide the solution of the task because it the student job to complete the task. You just have to undersatnd the user question and help the related to the task to understand it.\n Here are the details of the user internship task: {internship_task.description}.\n  Here is the coversation between the user and the AI-Manager: {coversations}.\n Here is the user message: {user_message} and responde according to the user message."
        response = client.completions.create(
            model="gpt-3.5-turbo-instruct-0914",
            prompt=prompt,
            temperature=1,
            top_p=1,
            frequency_penalty=0,
            presence_penalty=0,
            max_tokens=500,
        )
        ai_response = response.choices[0].text.strip()
        print("User Message: ", user_message)
        print("AI Response: ", ai_response)
        conv = Conversation.objects.create(user=user, message=user_message, response=ai_response, internship_task=internship_task)
        return conv
    
    except Exception as e:
        print(f"Error generating task: {str(e)}")
