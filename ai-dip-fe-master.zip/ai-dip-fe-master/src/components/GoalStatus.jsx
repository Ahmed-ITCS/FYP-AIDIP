import React from "react"
import { useNavigate } from "react-router-dom";


const GoalStatus = (props) => {
  
  const navigate = useNavigate();
  return (
    <div className="goal-status">
      <div className="goal-status-child" />
      <div className="heading">
        <img
          className="interface-essentialflame-icon"
          loading="lazy"
          alt=""
          src="/interface-essentialflame@2x.png"
        />
        <div className="manage-progress-wrapper">
          <div 
          className="manage-progress" 
          onClick={() => {navigate('/internship')}}>Manage Progress</div>
        </div>
      </div>
      <div className="heading-wrapper">
        <h1 className="heading1">Internship Status</h1>
      </div>
      <div className="progress-wrapper">
        <div className="progress">
          <div className="progress-parent" >
            <div className="progress1">Progress</div>
            <div className="div">{props.Data.progress || '0'}%</div>
          </div>
          <div className="rectangle-parent3">
            <div className="frame-child7"/>
            <div className="frame-child8" style={{width: `${props.Data.progress}%`}}/>
          </div>
        </div>
      </div>
    </div>
  );
};
export default GoalStatus;