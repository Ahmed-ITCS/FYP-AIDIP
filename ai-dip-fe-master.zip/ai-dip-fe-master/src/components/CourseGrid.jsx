import React from "react"


const CourseGrid = () => {
  return (
          <div className="course-grid">
            <div className="course-tutors">
              <img
                className="course-icon"
                loading="lazy"
                alt=""
                src="/course@2x.png"
              />

              <img
                className="tutors-icon"
                loading="lazy"
                alt=""
                src="/tutors@2x.png"
              />
            </div>
          </div>
  )
}
export default CourseGrid;