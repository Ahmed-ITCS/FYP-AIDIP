import React from "react"


const LatestCourse = () => {
  return (
    <div className="latest-course">
      <div className="pattern-matcher-parent">
        <img className="pattern-matcher-icon" alt="" src="/pattern-matcher.svg" />
        <img className="illustration-icon" alt="" src="/illustration.svg" />
      </div>
      <div className="pagination">
        <div className="div1">04</div>
        <div className="div2">03</div>
        <div className="div3">02</div>
        <div className="div4">01</div>
      </div>
      <div className="course-title-wrapper">
        <div className="course-title">
          <div className="frame-parent4">
            <div className="system-uiux-designer-parent">
              <h3 className="system-uiux-designer">System UI/UX Designer</h3>
              <div className="learn-how-to-container">
                <p className="learn-how-to">Learn how to create beautiful scenes</p>
                <p className="in-illustrator-tips">
                  in illustrator. Tips and Tricks with real
                </p>
                <p className="life-projects-and">life projects and case studies.</p>
              </div>
            </div>
            <div className="people-enrolled-so">121 people enrolled so far!</div>
          </div>
          <div className="frame-parent5">
            <div className="frame-parent6">
              <img
                className="group-icon"
                loading="lazy"
                alt=""
                src="/group-40125.svg"
              />
              <div className="number">
                <div className="div5">+115</div>
              </div>
            </div>
            <div className="enroll-today">Enroll Today!</div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default LatestCourse;