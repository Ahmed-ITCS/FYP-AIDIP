import React, { useEffect, useState } from 'react';
import axios from "axios";

const LeaderBoard = () => {
  const [candidates, setCandidates] = useState([]);

  useEffect(() => {
    const fetchCandidates = async () => {
      const token = localStorage.getItem('accessToken');
      try {
        const list_response = await axios.get("http://127.0.0.1:8000/api/leaderboard/", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        if (list_response.status === 200) {
          setCandidates(list_response.data);
        } else if (list_response.status === 204) {
          setCandidates([]);
        }
      } catch (error) {
        console.error("Error fetching candidates", error);
      }
    };
    fetchCandidates();
  }, []);

  return (
    <div className="rectangle-parent9">
      <div className="frame-child14" />
      <div className="frame-parent8">
        <div className="frame-wrapper5">
          <div className="leader-board-wrapper">
            <h1 className="leader-board">Leader Board</h1>
          </div>
        </div>
        <div className="frame-parent9">
          <div className="frame-wrapper6">
            <div className="shape-combiner-parent">
              <div className="shape-combiner" />
              {candidates.length > 0 && (
                <div className="frame-parent10">
                  <div className="container">
                    <div className="div6">01</div>
                  </div>
                  <div className="frame-wrapper7">
                    <div className="rectangle-parent10">
                      <div className="frame-child15" />
                      <img
                        className="frame-child16"
                        loading="lazy"
                        alt=""
                        src={`http://127.0.0.1:8000/${candidates[0].profile_photo}`}
                      />
                    </div>
                  </div>
                  <div className="error-handler">
                    <div className="frame-parent11">
                      <div className="devon-lane-wrapper">
                        <h2 className="devon-lane">{candidates[0].first_name} {candidates[0].last_name}</h2>
                      </div>
                      <div className="front-end-developer">{candidates[0].category}</div>
                    </div>
                  </div>
                </div>
              )}
              {candidates.length > 1 && (
                <div className="control-unit-wrapper">
                  <b className="control-unit">{candidates[0].skill_score}</b>
                </div>
              )}
            </div>
          </div>
          {candidates.length > 1 && (
            <div className="rectangle-parent11">
              <div className="frame-child17" />
              <div className="frame-parent12" style={{ width: '400px' }}>
                <div className="input-divider-wrapper">
                  <div className="input-divider">02</div>
                </div>
                <div className="rectangle-parent12">
                  <div className="frame-child18" />
                  <img
                    className="frame-child19"
                    loading="lazy"
                    alt=""
                    src={`http://127.0.0.1:8000/${candidates[1].profile_photo}`}
                  />
                </div>
                <div className="logic-xor-gate">
                  <div className="frame-parent13">
                    <div className="ronald-pena-wrapper">
                      <h2 className="ronald-pena">{candidates[1].first_name} {candidates[1].last_name}</h2>
                    </div>
                    <div className="back-end-developer">{candidates[1].category}</div>
                  </div>
                </div>
              </div>
              <div className="logic-xnor-gate-wrapper">
                <b className="logic-xnor-gate">{candidates[1].skill_score}</b>
              </div>
            </div>
          )}
          {candidates.length > 2 && (
            <div className="frame-wrapper8">
              <div className="rectangle-parent13">
                <div className="frame-child20" />
                <div className="frame-parent14" style={{ width: '400px' }}>
                  <div className="frame">
                    <div className="div7">03</div>
                  </div>
                  <div className="rectangle-parent14">
                    <div className="frame-child21" />
                    <img
                      className="frame-child22"
                      loading="lazy"
                      alt=""
                      src={`http://127.0.0.1:8000/${candidates[2].profile_photo}`}
                    />
                  </div>
                  <div className="frame-wrapper9">
                    <div className="frame-parent15">
                      <div className="elanor-davis-wrapper">
                        <h2 className="elanor-davis">{candidates[2].first_name} {candidates[2].last_name}</h2>
                      </div>
                      <div className="front-end-developer1">{candidates[2].category}</div>
                    </div>
                  </div>
                </div>
                <div className="wrapper1">
                  <b className="b">{candidates[2].skill_score}</b>
                </div>
              </div>
            </div>
          )}
          {candidates.length > 3 && (
            <div className="frame-wrapper10">
              <div className="rectangle-parent15">
                <div className="frame-child23" />
                <div className="frame-parent16" style={{ width: '400px' }}>
                  <div className="wrapper2">
                    <div className="div8">04</div>
                  </div>
                  <div className="rectangle-parent16">
                    <div className="frame-child24" />
                    <img
                      className="frame-child25"
                      loading="lazy"
                      alt=""
                      src={`http://127.0.0.1:8000/${candidates[3].profile_photo}`}
                    />
                  </div>
                  <div className="frame-wrapper11">
                    <div className="frame-parent17">
                      <div className="david-brow-wrapper">
                        <h2 className="david-brow">{candidates[3].first_name} {candidates[3].last_name}</h2>
                      </div>
                      <div className="full-stack-developer">{candidates[3].category}</div>
                    </div>
                  </div>
                </div>
                <div className="wrapper3">
                  <b className="b1">{candidates[3].skill_score}</b>
                </div>
              </div>
            </div>
          )}
          {candidates.length > 4 && (
            <div className="rectangle-parent17">
              <div className="frame-child26" />
              <div className="frame-parent18">
                <div className="input-multiplier-parent" style={{ width: '450px' }}>
                  <div className="input-multiplier">
                    <div className="output-merger">05</div>
                  </div>
                  <div className="frame-wrapper12">
                    <div className="rectangle-parent18">
                      <div className="frame-child27" />
                      <img
                        className="logic-operator-icon"
                        loading="lazy"
                        alt=""
                        src={`http://127.0.0.1:8000/${candidates[4].profile_photo}`}
                      />
                    </div>
                  </div>
                  <div className="frame-wrapper13">
                    <div className="frame-parent19">
                      <div className="john-ibram-wrapper">
                        <h2 className="john-ibram">{candidates[4].first_name} {candidates[4].last_name}</h2>
                      </div>
                      <div className="back-end-developer1">{candidates[4].category}</div>
                    </div>
                  </div>
                </div>
                <div className="wrapper4">
                  <b className="b2">{candidates[4].skill_score}</b>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default LeaderBoard;
