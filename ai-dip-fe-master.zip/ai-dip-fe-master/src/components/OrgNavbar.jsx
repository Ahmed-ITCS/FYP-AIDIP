import React, {useEffect, useState} from 'react'
import axios from 'axios';
import "../style/OrgNavbar.css";
import { NavLink } from 'react-router-dom';

const OrgNavbar = () => {
    const [user, setUser] = useState('');
    useEffect(() => {
        const fetchProfile = async () => {
            const token = localStorage.getItem('accessToken');
            try {
                const response = await axios.get("http://127.0.0.1:8000/api/org-profile/", {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setUser(response.data)
            }
            catch (error) {
                console.error(error.message || 'An error occurred');
            }
        }
        fetchProfile();
    }, []);
    return(
        <div>
            <div className="vertical-nav bg-white" id="sidebar">
                <div className="py-4 px-3 mb-4 bg-light">
                    <div className="media d-flex align-items-center">
                        <img 
                            src={user.profile_photo || '/default_profile_photo.jpg'} 
                            alt="..." style={{width: '60px'}} className="mr-3 rounded-circle img-thumbnail shadow-sm"/>
                    <div className="media-body">
                        <h4 className="m-0">{user.FullName}</h4>
                        <p className="font-weight-light text-muted mb-0">{user.RoleAtOrganization}</p>
                    </div>
                    </div>
                </div>

                <p className="text-gray font-weight-bold text-uppercase px-3 small pb-4 mb-0">Main</p>

                <ul style={{marginLeft: '30px'}} className="nav flex-column bg-white mb-0">
                    <li className="nav-item">
                    <NavLink to={'/org/home'} className="nav-link text-dark font-italic"><i className="fa fa-th-large mr-3 text-primary fa-fw"></i>
                        Home
                    </NavLink>
                    </li>
                    <li className="nav-item">
                    <NavLink to={'/org/accepted-offers'} className="nav-link text-dark font-italic"><i className="fa fa-address-card mr-3 text-primary fa-fw"></i>
                        Accepted Offers
                    </NavLink>
                    </li>
                    <li className="nav-item">
                    <NavLink to={'/org/sended-offers'} className="nav-link text-dark font-italic"><i className="fa fa-cubes mr-3 text-primary fa-fw"></i>
                        Sended Offers
                    </NavLink>
                    </li>
                    <li className="nav-item">
                    <NavLink to={'/org/logout'} className="nav-link text-dark font-italic"><i className="fa fa-cog fa-1x mr-3 text-primary fa-fw"></i>
                        Logout
                    </NavLink>
                    </li>
                </ul>
            </div>

                
        </div>
    )
};
export default OrgNavbar;