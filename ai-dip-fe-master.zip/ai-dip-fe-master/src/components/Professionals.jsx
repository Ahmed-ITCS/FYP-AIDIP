import React from "react"


const Professionals = () => {
  return (
    <div className="my-tutors">
      <div className="professionals">Professionals</div>
      <div className="my-tutors-inner">
        <div className="frame-parent">
          <div className="frame-group">
            <div className="rectangle-parent">
              <div className="frame-child" />
              <img
                className="frame-item"
                loading="lazy"
                alt=""
                src="/rectangle-6460@2x.png"
              />
              <img
                className="interface-essentialemail-2-icon"
                loading="lazy"
                alt=""
                src="/interface-essentialemail2@2x.png"
              />
              <div className="frame-wrapper">
                <div className="frame-container">
                  <div className="anglea-taylor-parent">
                    <b className="anglea-taylor">Anglea Taylor</b>
                    <div className="senior-php-developer">Senior PHP Developer</div>
                  </div>
                  <div className="frame-inner" />
                </div>
              </div>
            </div>
            <div className="rectangle-group">
              <div className="rectangle-div" />
              <div className="rectangle-container">
                <img
                  className="rectangle-icon"
                  loading="lazy"
                  alt=""
                  src="/rectangle-6460-1@2x.png"
                />
                <div className="frame-div">
                  <div className="mike-taylor-parent">
                    <b className="mike-taylor">Mike Taylor</b>
                    <div className="team-lead-at">Team Lead at Google</div>
                  </div>
                </div>
              </div>
              <img
                className="interface-essentialemail-2-icon1"
                loading="lazy"
                alt=""
                src="/interface-essentialemail2-1@2x.png"
              />
              <div className="ellipse-wrapper">
                <div className="ellipse-div" />
              </div>
            </div>
          </div>
          <div className="frame-parent1">
            <div className="group-div">
              <div className="frame-child1" />
              <img
                className="frame-child2"
                loading="lazy"
                alt=""
                src="/rectangle-6460-2@2x.png"
              />
              <img
                className="interface-essentialemail-2-icon2"
                loading="lazy"
                alt=""
                src="/interface-essentialemail2@2x.png"
              />
              <div className="frame-wrapper1">
                <div className="frame-parent2">
                  <div className="john-doe-parent">
                    <b className="john-doe">John Doe</b>
                    <div className="ui-designer-at">UI Designer at Uber</div>
                  </div>
                  <div className="frame-child3" />
                </div>
              </div>
            </div>
            <div className="rectangle-parent1">
              <div className="frame-child4" />
              <div className="rectangle-parent2">
                <img
                  className="frame-child5"
                  loading="lazy"
                  alt=""
                  src="/rectangle-6460-3@2x.png"
                />
                <div className="frame-wrapper2">
                  <div className="michelle-gundz-parent">
                    <b className="michelle-gundz">Michelle Gundz</b>
                    <div className="python-develooper">Python Develooper</div>
                  </div>
                </div>
              </div>
              <img
                className="interface-essentialemail-2-icon3"
                loading="lazy"
                alt=""
                src="/interface-essentialemail2-1@2x.png"
              />
              <div className="ellipse-container">
                <div className="frame-child6" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  );
};
export default Professionals;