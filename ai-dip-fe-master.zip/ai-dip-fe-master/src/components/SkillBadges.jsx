import React from "react"


const SkillBadges = (props) => {
  const skills = props.Data;
  if (skills.length === 0) {
    return (
      <div className="rectangle-parent4">
        <div className="frame-child9" />
        <div className="your-skills-badges-wrapper">
          <div className="your-skills-badges">Your Skills Badges</div>
        </div>
        <div className="frame-parent3">
          
        </div>
      </div>
    )
  }
  return (
    <div className="rectangle-parent4">
      <div className="frame-child9" />
      <div className="your-skills-badges-wrapper">
        <div className="your-skills-badges">Your Skills Badges</div>
      </div>
      {skills.length > 0 && (
        <div className="frame-parent3">
          {skills.map((skill) => (
            <img
              key={skill.id}
              className="user-skills-badge"
              loading="lazy"
              alt=""
              src={`${skill.skill.skill_name}.jpg`}
            />
          ))}
        </div>
      )}
    </div>

  );
};
export default SkillBadges;