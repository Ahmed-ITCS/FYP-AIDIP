import React from "react"
import { NavLink } from "react-router-dom";


const TopSide = () => {
  return (
    <section className="top">
      <div className="top-bar">
        <div className="app-bar">
          <div className="app-bar1">
            <NavLink to="/logout">
            <img className="icon1" loading="lazy" alt="" src="/lock-svgrepo-com.svg" />
            </NavLink>
            <NavLink to="/settings">
            <img className="icon2" loading="lazy" alt="" src="/general--settings.svg" />
            </NavLink>
          </div>
        </div>
      </div>
      <div className="header-wrapper">
        <div className="header">
          <div className="text-parent">
            <div className="text1">
              <h1 className="your-personal-internship">
                Your Personal Internship Platform
              </h1>
              <div className="based-on-yoru">Based on yoru preferences</div>
            </div>
            <div className="frame-wrapper4">
              <div className="icon-search-parent">
                <div className="rectangle-parent8">
                  <input className="rectangle-input" type="text" placeholder="Search for a course" />
                  
                </div>
              </div>
            </div>
          </div>
          <b className="go">GO</b>
          <div className="header-child" />
        </div>
      </div>
    </section>

  );
};
export default TopSide;