import React from "react"
import "../style/index.css"


const TopSide2 = () => {
  return (
    <div className="desktop-1">
      <div className="dashboard-parent">
        <main className="dashboard">
          <section className="dashboard-child"></section>

          <section className="top">
            <div className="top-bar">
              <div className="app-bar">
                <img className="icon" alt="" src="/icon.svg" />
                <div className="app-bar1">
                  <img className="icon1" loading="lazy" alt="" src="/icon-1@2x.png" />
                  <img className="icon2" loading="lazy" alt="" src="/icon-2@2x.png" />
                </div>
              </div>
            </div>
            <div className="header-wrapper">
              <div className="header">
                <div className="text-parent">
                  <div className="text1">
                    <h1 className="your-personal-internship">
                      Your Personal Internship Platform
                    </h1>
                    <div className="based-on-yoru">Based on yoru preferences</div>
                  </div>
                  <div className="frame-wrapper4">
                    <div className="icon-search-parent">
                      <img
                        className="icon-search"
                        loading="lazy"
                        alt=""
                        src="/icon--search.svg"
                      />
                      <div className="rectangle-parent8">
                        <input className="rectangle-input" type="text" />
                        <div className="search-for-a">Search for a course</div>
                      </div>
                    </div>
                  </div>
                </div>
                <b className="go">GO</b>
                <div className="header-child" />
              </div>
            </div>
          </section>
        </main>
      </div>
    </div>


  );
};
export default TopSide2;