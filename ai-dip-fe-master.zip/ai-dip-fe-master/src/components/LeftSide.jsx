import React, {useEffect, useState} from "react"
import { useNavigate, useLocation} from "react-router-dom";
import "../style/index.css"

const LeftSide = (props) => {
  const navigate = useNavigate();
  const [activeButton, setActiveButton] = useState('/dashboard');
  const location = useLocation();
  const pathname = location.pathname;
  
  useEffect(() => {
    if (pathname !== activeButton) {
      setActiveButton(pathname);
    }
  }, [pathname, activeButton])

  const handleButtonClick = (buttonName) => {
    setActiveButton(buttonName);
    navigate(`/${buttonName}`);
  };
  
  const { first_name, last_name, profile_photo } = props.Data.profile;
  return (
    <section className="left-side">
      <div className="header-nav">
        <div className="header-nav-child" />
        <div className="text">
          <h2 className="ai-dip">AI-DIP</h2>
          <div className="internship-platform">Internship Platform</div>
        </div>
        <div className="user">
          <img
            className="user-child"
            loading="lazy"
            alt=""
            src={profile_photo ? (`http://127.0.0.1:8000/${profile_photo}`) : ('/default-profile-photo.jpg')}
          />
          <div className="hunain-baloch-wrapper">
            <h1 className="hunain-baloch">
              {`${first_name} ${last_name}`}
            </h1>
          </div>
        </div>
      </div>
      <div className="nav-wrapper">
        <div className="nav">
          <div className="nav-inner">
            <div className="rectangle-parent5">
              <div className="frame-child10" />
              <div className="frame-parent7">
                <button className={`general-discover-parent ${activeButton === '/dashboard' ? 'active' : ''}`} 
                  onClick={() => handleButtonClick('dashboard')}>
                  <img
                    className="general-discover"
                    alt=""
                    src="/general--category.svg"
                  />
                  <div className="dashboard-wrapper" >
                    <div className="dashboard1">
                      Dashboard
                    </div>
                  </div>
                </button>
                <button 
                  className={`general-discover-parent ${activeButton === '/skills' ? 'active' : ''}`} 
                  onClick={() => handleButtonClick('skills')}>
                  <img
                    className="general-discover"
                    loading="lazy"
                    alt=""
                    src="/general--discover.svg"
                  />
                  <div className="skills-wrapper" >
                    <div className="skills">
                      Skills
                    </div>
                  </div>
                </button>
                <button className={`general-discover-parent ${activeButton === '/internship' ? 'active' : ''}`} 
                  onClick={() => handleButtonClick('internship')}>
                  <img
                    className="general-discover"
                    loading="lazy"
                    alt=""
                    src="/general--calendar-1.svg"
                  />
                  <div className="internships-wrapper" >
                    <div className="internships">
                      Internship
                    </div>
                  </div>
                </button>
                <button className={`general-discover-parent ${activeButton === '/profile' ? 'active' : ''}`} 
                  onClick={() => handleButtonClick('profile')}>
                  <img
                    className="general-discover"
                    loading="lazy"
                    alt=""
                    src="/profile-2-svgrepo-com.svg"
                  />
                  <div className="profile-wrapper" >
                    <div className="profile">
                      Profile
                    </div>
                  </div>
                </button>
                <button className={`general-discover-parent ${activeButton === '/ai-manager' ? 'active' : ''}`} 
                  onClick={() => handleButtonClick('ai-manager')}>
                  <img
                    className="general-settings"
                    loading="lazy"
                    alt=""
                    src="/general--settings.svg"
                  />
                  <div className="my-settings-wrapper" >
                    <div className="my-settings">
                      AI Manager
                    </div>
                  </div>
                </button>
              </div>
            </div>
          </div>
          <div className="rectangle-parent6"> 
            <div className="frame-child12" />
            <div className="rectangle-parent7" onClick={() => {navigate('/offers')}}>
              <div className="frame-child13" />
              <div className="frame-wrapper3">
                <div className="offer-opportunity-parent">
                  <div className="offer-opportunity">Offer &amp; Opportunity</div>
                  <div className="from-companies">From Companies</div>
                </div>
              </div>
              <img
                className="general-lightning-1"
                alt=""
                src="/general--lightning-1.svg"
              />
            </div>
          </div>
        </div>
      </div>
      <div className="upgrade-wrapper">
        <div className="upgrade">
          <div className="nested-structure" />
          <h2 className="upgrade-to-pro">Upgrade to Pro</h2>
          <div className="get-your-projects-container">
            <p className="get-your-projects">Get your projects and</p>
            <p className="profile-reviewed-by">profile reviewed by</p>
            <p className="software-engineers">Software Engineers.</p>
          </div>
          <div className="upgrade-today">Upgrade Today!</div>
          <img
            className="with-rocket-girl"
            loading="lazy"
            alt=""
            src="/with-rocket-girl@2x.png"
          />
        </div>
      </div>
    </section>

  );
};
export default LeftSide;