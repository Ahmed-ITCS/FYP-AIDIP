import React, { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom";
import axios from "axios";
import LeaderBoard from "../components/LeaderBoard";
import LeftSide from "../components/LeftSide";
import Professionals from "../components/Professionals";
import SkillBadges from "../components/SkillBadges";
import TopSide from "../components/TopSide";
import LatestCourse from "../components/LatestCourse";
import GoalStatus from "../components/GoalStatus";
import CourseGrid from "../components/CourseGrid";
import "../style/index.css"


const Dashboard = () => {
  const [userData, setUserData] = useState({ profile: { first_name: "", last_name: ""}});
  const [intern_status, setInternStatus] = useState('');
  const [user_skills, setUserSkills] = useState([]);
  const navigate = useNavigate();

  

    useEffect(() => {
      const fetchData = async () => {
        const token = localStorage.getItem('accessToken');
        try {
          const response = await axios.get("http://127.0.0.1:8000/api/home/", {
            headers: {
              Authorization: `Bearer ${token}`, // Include the token in the request headers
            },
          });
          if (response.status === 403) {
            navigate('/login');
          }
          else if (response.status === 405) {
            navigate('/create-profile')
          }
          else {
            setUserData(response.data);
          }
          
        }
        catch (error) {
          if (error === undefined) {
       
          } else if (error.response !== undefined) {
            if (error.response.status === 403) {
              navigate('/login');
            } else if (error.response.status === 405) {
              navigate('/create-profile')
            } 
          
          }
          else {
            
          }
          
        }
      };

      fetchData();
    }, [navigate]);

    

    useEffect(() => {
      const fetchInternStatus = async () => {
        const token = localStorage.getItem('accessToken');
        try {
          
          const response = await axios.get("http://127.0.0.1:8000/api/internship/status/", {
            headers: {
              Authorization: `Bearer ${token}`, // Include the token in the request headers
            },
          });
          if (response.status === 403) {
            navigate('/login');
          }
          else if (response.status === 204) {
            setInternStatus(response.data);
          }
          else if (response.status === 200) {
            setInternStatus(response.data);
          }
        } catch (error) {
          if (error === undefined) {
       
          } else if (error.response !== undefined) {
            if (error.response.status === 403) {
              navigate('/login');
            }
          
          }
          
        }
      };
      fetchInternStatus();
    }, [navigate]);

   useEffect(() => {
      const fetchUserSkills = async () => {
        const token = localStorage.getItem('accessToken');
        try {
          const response = await axios.get("http://127.0.0.1:8000/api/user-skill-badge/", {
            headers: {
              Authorization: `Bearer ${token}`, // Include the token in the request headers
            },
          });
          if (response.status === 200) {
            setUserSkills(response.data);
          }
          else if (response.status === 204) {
            setUserSkills([]);
          }
          else if (response.status === 403) {
            navigate('/login');
          }
        } catch (error) {
          if (error === undefined) {
       
          } else if (error.response !== undefined) {
            if (error.response.status === 403) {
              navigate('/login');
            }
          
          }
          
          }
      };

      fetchUserSkills();
    }, [navigate]);

    const data = userData;
    //console.log('skills = ', user_skills[0].id);
  return (
    <div className="desktop-1">
      <div className="dashboard-parent">
          <main className="dashboard">
            <section className="dashboard-child"></section>
            {/* Professionals */}
            <Professionals />
            

            {/* Internship Status */}
            <GoalStatus Data={intern_status} />

            {/* Your Skills Badges */}
            <SkillBadges Data={user_skills}/>

            {/* Latest Course */}
            <LatestCourse />

            {/* Course Grid */}
            <CourseGrid />

            {/* Left Side Pannel */}
            <LeftSide Data={data}/>

            {/* Top Side Pannel */}
            <TopSide />

            {/* Leader Board */}
            <LeaderBoard />

          </main>
        </div>
    </div>
  );
};
export default Dashboard;