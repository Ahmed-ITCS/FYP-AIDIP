import React, { useState, useEffect } from 'react';
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "../style/CreateProfile.css";

const OrgCreateProfile = () => {
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    profile_photo: null,
    OrganizationName: '',
    OrganizationCity: '',
    OrganizationCountry: '',
    OrganizationSite: '',
    RoleAtOrganization: '',
    FullName: ''
  });
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProfile = async () => {
      const token = localStorage.getItem('accessToken');
      try {
        const response = await axios.get("http://127.0.0.1:8000/api/org-profile/", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        console.log('response = ', response.data)
        if (response.status === 403) {
          navigate('/org/login');
        }
        else if (response.status === 200) {
          navigate('/org/home')
        }
      } catch (error) {
        if (error.response.data.detail === 'No Profile matches the given query.') {
          setError('');
        }
        else {
          if (error.response.status === 403) {
            navigate('/org/login');
          }
        }
      }
    };

    fetchProfile();
  }, [navigate]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleFileChange = (e) => {
    setFormData({
      ...formData,
      profile_photo: e.target.files[0]
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem('accessToken');

    const data = new FormData();
    Object.keys(formData).forEach((key) => {
      data.append(key, formData[key]);
    });

    try {
      const response = await axios.post('http://127.0.0.1:8000/api/org-profile/', data, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.status === 201) {
        navigate('/org/home');
      }
    } catch (error) {
      if (error.response.status === 403) {
        navigate('/org/login');
      }
      else if (error.response.status === 400) {
        alert('Please fill all the fields');
      }
    }
  };


  return (
    <div>
      {error ? (
        <div className="error-message">
          {error}
        </div>
        ) : (
        <div className="settings">
          <h2 className="settings-title">Complete Profile</h2>
          <form className="settings-form" method="post" onSubmit={handleSubmit} >
            <div className="form-group">
              <label htmlFor="profile_photo">Profile Photo</label>
              <input type="file" id="profile_photo" name="profile_photo" onChange={handleFileChange} />
            </div>

            <div className="form-group">
              <label htmlFor="FullName">Full Name</label>
              <input type="text" id="FullName" name="FullName" onChange={handleInputChange} />
            </div>

            <div className="form-group">
              <label htmlFor="OrganizationName">Organization Name</label>
              <input type="text" id="OrganizationName" name="OrganizationName" onChange={handleInputChange} />
            </div>

            <div className="form-group">
              <label htmlFor="OrganizationCity">Organization City</label>
              <input type="text" id="OrganizationCity" name="OrganizationCity" onChange={handleInputChange} />
            </div>

            <div className="form-group">
              <label htmlFor="OrganizationCountry">Organization Country</label>
              <input type="text" id="OrganizationCountry" name="OrganizationCountry" onChange={handleInputChange} />
            </div>

            <div className="form-group">
              <label htmlFor="OrganizationSite">Organization Website</label>
              <input type="text" id="OrganizationSite" name="OrganizationSite" onChange={handleInputChange} />
            </div>

            <div className="form-group">
              <label htmlFor="RoleAtOrganization">Role At Organization</label>
              <input type="text" id="RoleAtOrganization" name="RoleAtOrganization" onChange={handleInputChange} />
            </div>

            <button type="submit" className="save-button">Save Settings</button>
          </form>
        </div>
      )}
    </div>
  );
};

export default OrgCreateProfile;
