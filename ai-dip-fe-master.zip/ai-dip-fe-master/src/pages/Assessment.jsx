import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { useLocation } from "react-router-dom";
import LeftSide from "../components/LeftSide";
import TopSide2 from "../components/TopSide2";
import "../style/Assessment.css";
import "../style/AssessmentCheck.css";

const Assessment = () => {
  const location = useLocation();
  const { skill } = location.state;
  const [assessment, setAssessment] = useState({ questions: {} });
  const [userData, setUserData] = useState('');
  const [isVisible, setIsVisible] = useState(true);
  const [answers, setAnswers] = useState([]);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      const token = localStorage.getItem('accessToken');
      try {
        const response = await axios.get("http://127.0.0.1:8000/api/home/", {
          headers: {
            Authorization: `Bearer ${token}`, // Include the token in the request headers
          },
        });
        if (response.status === 403) {
          navigate('/login');
        }
        setUserData(response.data);
      } catch (error) {
        setError(error.response);
        if (error === undefined) {
       
        } else if (error.response !== undefined) {
          if (error.response.status === 403) {
            navigate('/login');
          }
        
        }
      }
    };

    fetchData();
  }, [navigate]);

  const handleSubmit1 = async (e) => {
    e.preventDefault();
    setIsVisible(false);
    console.log(assessment);

    const fetchAssessment = async () => {
      try {
        const assessment_response = await fetch(`http://127.0.0.1:8000/api/assessment/${skill.id}/`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('accessToken')}` // Ensure the user is authenticated
          },
        });
        if (assessment_response.status === 400) {
          navigate('/skills');
        }
        if (assessment_response.status === 307) {
          alert('Request Interrupted. Please try again.');
          navigate('/skills');
        }
        const data = await assessment_response.json();
        setAssessment(data);
        // Initialize answers state with empty answers
        const initialAnswers = Object.keys(data.questions).map((key, index) => ({
          questionNo: index + 1,
          question: data.questions[key],
          answer: ""
        }));
        setAnswers(initialAnswers);
      } catch (error) {
        setError(error.response);
        if (error === undefined) {
       
        } else if (error.response !== undefined) {
          if (error.response.status === 403) {
            navigate('/login');
          }
        
        }
      }
    };

    fetchAssessment();
  };

  const handleChange = (e, index) => {
    const newAnswers = [...answers];
    newAnswers[index].answer = e.target.value;
    setAnswers(newAnswers);
  };

  const handleSubmit2 = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        `http://127.0.0.1:8000/api/assessment/${skill.id}/`,
        { answers },
        {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('accessToken')}`,
          },
        }
      );
      if (response.status === 200) {
        navigate('/assessment-submission');
      }
    } catch (error) {
      setError(error.response);
      if (error === undefined) {
       
      } else if (error.response !== undefined) {
        if (error.response.status === 403) {
          navigate('/login');
        }
      
      }
    }
  };

  if (!userData) {
    return <div>Loading...</div>;
  }

  const data = userData;
  const { questions } = assessment;
  console.log(error);
  

  return (
    <div>
      {/* Left Side Panel */}
      <LeftSide Data={data} />

      {/* Top Side Panel */}
      <TopSide2 />

      {/* Right Side Panel */}
      <div className="react-js-skill-assessment-parent">
        <h2 className="react-js-skill">
          {skill.skill_name} Skill Assessment
          {isVisible && (
            <div id="myDiv" className="continue-button" onClick={handleSubmit1}>
              Start the test
            </div>
          )}
        </h2>
        <div className="frame-wrapper35">
          <div className="frame-parent45">
            <form className="frame-form" onSubmit={handleSubmit2}>
                
                  <div className="frame-parent46">
                  {Object.entries(questions).map(([key, question], index) => (
                    <div key={index} className="frame-wrapper36">
                      <div className="feature-a-parent">
                        <div className="feature-a">
                          <b className="reassign-answer-box">{index + 1}.</b>
                          <div className="new-e-s-feature-a">
                            <div className="new-e-s-feature-b">
                              <div className="which-new-es6">
                                {question}
                              </div>
                              <div className="which-new-e-s-feature">
                                <textarea
                                  className="which-new-e-s-feature-child"
                                  placeholder="Type your answer here...."
                                  rows={8}
                                  cols={29}
                                  value={answers[index]?.answer || ''}
                                  onChange={(e) => handleChange(e, index)}
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="frame-wrapper37">
                          <div className="rectangle-parent60">
                            <div className="frame-child89" />
                            <b className="point">1 point</b>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              {!isVisible && assessment.time !== undefined ? (
                <button type="submit" className="continue-button">Submit Test</button>
              ) : (<div>Loading......</div>)}
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Assessment;
