// src/pages/MainPage.jsx
import React from 'react';
import { useEffect} from "react";

const MainPage = () => {
  useEffect(() => {
    const createAndAppendStylesheet = (href) => {
      const stylesheet = document.createElement('link');
      stylesheet.rel = 'stylesheet';
      stylesheet.href = href;
      document.head.appendChild(stylesheet);
      return stylesheet;
    };

    const stylesheets = [
      createAndAppendStylesheet('/assets/css/bootstrap-5.0.0-beta2.min.css'),
      createAndAppendStylesheet('/assets/css/LineIcons.2.0.css'),
      createAndAppendStylesheet('/assets/css/tiny-slider.css'),
      createAndAppendStylesheet('/assets/css/animate.css'),
      createAndAppendStylesheet('/assets/css/main.css')
    ];
    
    return () => {
      stylesheets.forEach(stylesheet => {
        if (stylesheet && document.head.contains(stylesheet)) {
          document.head.removeChild(stylesheet);
        }
      });
    };
    
  }, []);


  return (
  <>
    <meta charSet="utf-8" />
    <meta httpEquiv="x-ua-compatible" content="ie=edge" />
    <title>AI-DIP | AI-Driven Internship Platform</title>
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link
      rel="shortcut icon"
      type="image/x-icon"
      href="../assets/images/favicon.svg"
    />
    {/* ========================= CSS here ========================= */}
    {/* <link rel="stylesheet" href="../assets/css/bootstrap-5.0.0-beta2.min.css" />
    <link rel="stylesheet" href="../assets/css/LineIcons.2.0.css" />
    <link rel="stylesheet" href="../assets/css/tiny-slider.css" />
    <link rel="stylesheet" href="../assets/css/animate.css" />
    <link rel="stylesheet" href="../assets/css/main.css" /> */}
    {/* Place favicon.ico in the root directory */}
    {/* ========================= preloader start ========================= */}
    {/* <div className="preloader">
      <div className="loader">
        <div className="spinner">
          <div className="spinner-container">
            <div className="spinner-rotator">
              <div className="spinner-left">
                <div className="spinner-circle" />
              </div>
              <div className="spinner-right">
                <div className="spinner-circle" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div> */}
    {/* preloader end */}
    {/* ========================= header start ========================= */}
    <header className="header">
      <div className="navbar-area">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-lg-12">
              <nav className="navbar navbar-expand-lg">
                <a className="navbar-brand" href="index.html">
                  <h3 style={{ color: "#37C2CC", fontSize: 25 }}>
                    {" "}
                    <span
                      style={{
                        backgroundColor: "#37C2CC",
                        color: "white",
                        borderRadius: "50%",
                        padding: 3,
                        marginRight: "-2px"
                      }}
                    >
                      AI
                    </span>{" "}
                    DIP
                  </h3>
                </a>
                <button
                  className="navbar-toggler"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#navbarSupportedContent"
                  aria-controls="navbarSupportedContent"
                  aria-expanded="false"
                  aria-label="Toggle navigation"
                >
                  <span className="toggler-icon" />
                  <span className="toggler-icon" />
                  <span className="toggler-icon" />
                </button>
                <div
                  className="collapse navbar-collapse sub-menu-bar"
                  id="navbarSupportedContent"
                >
                  <div className="ms-auto" style={{paddingLeft: '325px'}}>
                    <ul id="nav" className="navbar-nav ms-auto">
                      <li className="nav-item">
                        <a className="page-scroll active" href="#home">
                          Home
                        </a>
                      </li>
                      <li className="nav-item">
                        <a className="page-scroll" href="#about">
                          About
                        </a>
                      </li>
                      <li className="nav-item">
                        <a className="page-scroll" href="#features">
                          Features
                        </a>
                      </li>
                      <li className="nav-item">
                        <a className="" href="#0">
                          Pricing
                        </a>
                      </li>
                      <li className="nav-item">
                        <a className="" href="#0">
                          Team
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
                {/* navbar collapse */}
                <div className="header-btn">
                  <a
                    href="http://localhost:3000/register"
                    className="main-btn btn-hover"
                    style={{
                      color: "#37C2CC",
                      backgroundColor: "white",
                      border: "3px solid #37C2CC",
                      borderRadius: 10
                    }}
                  >
                    Apply as Interne
                  </a>
                </div>
                <div className="header-btn">
                  <a
                    href="http://localhost:3000/org/register"
                    className="main-btn btn-hover"
                  >
                    Find Candidates
                  </a>
                </div>
              </nav>
              {/* navbar */}
            </div>
          </div>
          {/* row */}
        </div>
        {/* container */}
      </div>
      {/* navbar area */}
    </header>
    {/* ========================= header end ========================= */}
    {/* ========================= hero-section start ========================= */}
    <section id="home" className="hero-section">
      <div className="container">
        <div className="row align-items-center">
          <div className="col-xl-6 col-lg-6 col-md-10">
            <div className="hero-content">
              <h1>Welcome to "AI-Driven Internship Platform"</h1>
              <p>
                Bridging the academic and professional domains for computer
                science and software engineering students.
              </p>
              <a
                href="http://localhost:3000/register"
                className="main-btn btn-hover"
              >
                Start Internship
              </a>
              <p style={{ fontSize: 12, paddingTop: 5 }}>
                Join us and enrich your skill set and understanding.
              </p>
            </div>
          </div>
          <div className="col-xxl-6 col-xl-6 col-lg-6">
            <div className="hero-image text-center text-lg-end">
              <img src="/dashboard-main.jpeg" alt="" />
            </div>
          </div>
        </div>
      </div>
    </section>
    {/* ========================= hero-section end ========================= */}
    {/* ========================= about-section start ========================= */}
    <section id="about" className="about-section">
      <div className="container">
        <div className="row">
          <div className="col-lg-6 order-last order-lg-first">
            <div className="about-image">
              <img src="/internship-page.png" alt="" />
            </div>
          </div>
          <div className="col-lg-6" style={{marginLeft: '650px'}}>
            <div className="about-content-wrapper">
              <div className="section-title">
                <h2 className="mb-20">Real-World Problem Solving</h2>
                <p className="mb-30">
                  Gain hands-on experience by solving real-world problems.
                </p>
                <a
                  href="http://localhost:3000/register"
                  className="main-btn btn-hover border-btn"
                >
                  Solve Problems
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    {/* ========================= about-section end ========================= */}
    {/* ========================= feature-section start ========================= */}
    <section id="features" className="feature-section">
      <div className="container">
        <div className="row">
          <div className="col-lg-5 col-md-10">
            <div className="section-title mb-60">
              <h2 className="mb-20">Modern design with Essential Features</h2>
              <div className="features-image">
                <img
                  src="/user-profile.png"
                  width="80%"
                  style={{
                    borderRadius: 15,
                    border: "5px solid rgb(129, 129, 129)"
                  }}
                  alt=""
                />
              </div>
            </div>
          </div>
          <div className="col-lg-7">
            <div className="row">
              <div className="col-lg-6 col-md-6">
                <div className="single-feature">
                  <div className="feature-icon">
                    <i className="lni lni-display" />
                  </div>
                  <div className="feature-content">
                    <h4>AI-DRIVEN PROJECTS</h4>
                    <p>
                      Get guidance from an AI Manager while engaging in AI-driven
                      projects.
                    </p>
                  </div>
                </div>
              </div>
              <div className="col-lg-6 col-md-6">
                <div className="single-feature">
                  <div className="feature-icon">
                    <i className="lni lni-compass" />
                  </div>
                  <div className="feature-content">
                    <h4>AI Manager Guidance</h4>
                    <p>
                      Lorem ipsum dolor amet, consetetur sadipscing elitr, diam
                      nonu eirmod tem invidunt.
                    </p>
                  </div>
                </div>
              </div>
              <div className="col-lg-6 col-md-6">
                <div className="single-feature">
                  <div className="feature-icon">
                    <i className="lni lni-grid-alt" />
                  </div>
                  <div className="feature-content">
                    <h4>INTERNSHIP OPPORTUNITIES</h4>
                    <p>
                      Explore conventional internship opportunities offered by IT
                      companies.
                    </p>
                  </div>
                </div>
              </div>
              <div className="col-lg-6 col-md-6">
                <div className="single-feature">
                  <div className="feature-icon">
                    <i className="lni lni-layers" />
                  </div>
                  <div className="feature-content">
                    <h4>Student Profiles</h4>
                    <p>
                      IT Service organizations can review student profiles and
                      express interest based on their skills scores.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    {/* ========================= feature-section end ========================= */}
    {/* ========================= cta-section start ========================= */}
    <section id="cta" className="cta-section pt-130 pb-100">
      <div className="container">
        <div className="row align-items-center">
          <div className="col-lg-6 col-md-10">
            <div className="cta-content-wrapper">
              <div className="section-title">
                <h2 className="mb-20">
                  Quick &amp; Easy to <br className="d-none d-lg-block" /> Find
                  Best Candidates.
                </h2>
                <p className="mb-30">
                  If you are from a Software House or IT Company and looking for
                  best candidate. Find students and Interns easily according to
                  the skills and technology with skills scores. Check the scores
                  of the skills gained by each interne. Show your interest after
                  reviewing the profile of the user. Just create your account and
                  get started!!!
                </p>
                <a
                  href="http://localhost:3000/org/register"
                  className="main-btn btn-hover border-btn"
                >
                  Find Candidates
                </a>
              </div>
            </div>
          </div>
          <div className="col-lg-6">
            <div className="cta-image text-lg-end">
              <img src="/org-dashboard.png" alt="" />
            </div>
          </div>
        </div>
      </div>
    </section>
    {/* ========================= cta-section end ========================= */}
    {/* ========================= footer start ========================= */}
    <footer className="footer pt-120">
      <div className="container">
        <div className="row">
          <div className="col-xl-3 col-lg-4 col-md-6 col-sm-10">
            <div className="footer-widget">
              <div className="logo">
                <a href="index.html">
                  <h3 style={{ color: "#37C2CC", fontSize: 25 }}>
                    <span
                      style={{
                        backgroundColor: "#37C2CC",
                        color: "white",
                        borderRadius: "50%",
                        padding: 3,
                        marginRight: "5px"
                      }}
                    >
                      AI
                    </span>
                    DIP
                  </h3>
                </a>
              </div>
              <p className="desc">
                Join us today and take the first step towards a rewarding career
                in AI and software engineering.
              </p>
              <ul className="social-links">
                <li>
                  <a href="#0">
                    <i className="lni lni-facebook" />
                  </a>
                </li>
                <li>
                  <a href="#0">
                    <i className="lni lni-linkedin" />
                  </a>
                </li>
                <li>
                  <a href="#0">
                    <i className="lni lni-instagram" />
                  </a>
                </li>
                <li>
                  <a href="#0">
                    <i className="lni lni-twitter" />
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="col-xl-2 col-lg-2 col-md-6 col-sm-6 offset-xl-1">
            <div className="footer-widget">
              <h3>About Us</h3>
              <ul className="links">
                <li>
                  <a href="#0">Home</a>
                </li>
                <li>
                  <a href="#0">About</a>
                </li>
                <li>
                  <a href="#0">Features</a>
                </li>
                <li>
                  <a href="#0">Contact</a>
                </li>
              </ul>
            </div>
          </div>
          <div className="col-xl-3 col-lg-2 col-md-6 col-sm-6">
            <div className="footer-widget">
              <h3>Services</h3>
              <ul className="links">
                <li>
                  <a href="http://localhost:3000/register">AI Manager Guidance</a>
                </li>
                <li>
                  <a href="http://localhost:3000/register">
                    Real-World Problem Solving
                  </a>
                </li>
                <li>
                  <a href="http://localhost:3000/org/register">Find Candidates</a>
                </li>
                <li>
                  <a href="http://localhost:3000/org/register">
                    Student Profiles
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="col-xl-3 col-lg-4 col-md-6">
            <div className="footer-widget">
              <h3>Subscribe Newsletter</h3>
              <form action="#">
                <input type="email" placeholder="Email" />
                <button className="main-btn btn-hover">Subscribe</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </footer>
    {/* ========================= footer end ========================= */}
    {/* ========================= scroll-top ========================= */}
    <a href="#nav" className="scroll-top btn-hover">
      <i className="lni lni-chevron-up" />
    </a>
    {/* ========================= JS here ========================= */}
  </>
)
}
export default MainPage;