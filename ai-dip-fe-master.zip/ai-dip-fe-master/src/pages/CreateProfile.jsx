import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "../style/CreateProfile.css";

const CreateProfile = () => {
  const [error, setError] = useState('');
  const [options, setOptions] = useState([]);
  const [selectedOption, setSelectedOption] = useState([]);
  const prevOptionsRef = useRef();
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    bio: '',
    phone_number: '',
    university_name: '',
    department: '',
    degree_name: '',
    graduation_year: '',
    profile_photo: null
  });
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProfile = async () => {
      const token = localStorage.getItem('accessToken');
      try {
        const response = await axios.get("http://127.0.0.1:8000/api/profile/", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        console.log('response = ', response.data)
        if (response.status === 403) {
          navigate('/login');
        }
        else if (response.status === 200) {
          navigate('/')
        }
      } catch (error) {
        if (error.response.data.detail === 'No Profile matches the given query.') {
          setError('');
        }
        else {
          if (error.response.status === 403) {
            navigate('/login');
          }
        }
      }
    };

    fetchProfile();
  }, [navigate]);

  useEffect(() => {
    const fetchOptions = async () => {
      const token = localStorage.getItem('accessToken');
      try {
        const response = await axios.get("http://127.0.0.1:8000/api/internship-options/", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        if (response.status === 403) {
          navigate('/login');
        }
        setOptions(response.data);
      } catch (error) {

        setError(error.response);
        if (error.status === 403) {
          navigate('/login');
        }
      }
    };

    fetchOptions();
  }, [navigate]);

  useEffect(() => {
    const prevOptions = prevOptionsRef.current;

    if (options.length > 0 || prevOptions !== options) {
      const uniqueOptions = Array.from(
        new Map(options.map((option) => [option.title, option])).values()
      );
      setSelectedOption(uniqueOptions);
    }

    prevOptionsRef.current = options;
  }, [options]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleFileChange = (e) => {
    setFormData({
      ...formData,
      profile_photo: e.target.files[0]
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem('accessToken');

    const data = new FormData();
    Object.keys(formData).forEach((key) => {
      data.append(key, formData[key]);
    });

    try {
      const response = await axios.post('http://127.0.0.1:8000/api/profile/', data, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.status === 201) {
        navigate('/');
      }
    } catch (error) {
      if (error.response.status === 403) {
        navigate('/login');
      }
      else if (error.response.status === 400) {
        alert('Please fill all the fields');
      }
    }
  };


  return (
    <div>
      {error ? (
        <div className="error-message">
          {error}
        </div>
        ) : (
        <div className="settings">
          <h2 className="settings-title">Complete Profile</h2>
          <form className="settings-form" method="post" onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="profile_photo">Profile Photo</label>
              <input type="file" id="profile_photo" name="profile_photo" onChange={handleFileChange} />
            </div>

            <div className="form-group">
              <label htmlFor="first_name">First Name</label>
              <input type="text" id="first_name" name="first_name" onChange={handleInputChange} />
            </div>

            <div className="form-group">
              <label htmlFor="last_name">Last Name</label>
              <input type="text" id="last_name" name="last_name" onChange={handleInputChange} />
            </div>

            <div className="form-group">
              <label htmlFor="category">Category</label>
              <select className='select' id="category" name="category" onChange={handleInputChange}>
                {selectedOption.map( (option, index) => (
                  <option key={index} value={option.title}>{option.title}</option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label htmlFor="bio">Bio</label>
              <input type="text" id="bio" name="bio" onChange={handleInputChange} />
            </div>

            <div className="form-group">
              <label htmlFor="phone_number">Phone Number</label>
              <input type="text" id="phone_number" name="phone_number" onChange={handleInputChange} />
            </div>

            <div className="form-group">
              <label htmlFor="university_name">University Name</label>
              <input type="text" id="university_name" name="university_name" onChange={handleInputChange} />
            </div>

            <div className="form-group">
              <label htmlFor="department">Department</label>
              <input type="text" id="department" name="department" onChange={handleInputChange} />
            </div>

            <div className="form-group">
              <label htmlFor="degree_name">Degree Name</label>
              <input type="text" id="degree_name" name="degree_name" onChange={handleInputChange} />
            </div>

            <div className="form-group">
              <label htmlFor="graduation_year">Graduation Year</label>
              <input type="text" id="graduation_year" name="graduation_year" onChange={handleInputChange} />
            </div>

            <button type="submit" className="save-button">Save Settings</button>
          </form>
        </div>
      )}
    </div>
  );
};

export default CreateProfile;
