import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../style/Login.css';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://127.0.0.1:8000/api/login/', {
        username: email,
        password: password,
      });

      const data = response.data;
      localStorage.setItem('accessToken', data.access);
      localStorage.setItem('refreshToken', data.refresh);
      if (data.profile.length === 0) {
        navigate('/create-profile');
      } else {
        navigate('/dashboard');
      }
    } catch (error) {
      if (error.response) {
        setError(error.response.data.detail || 'An error occurred during login');
      } else {
        setError(error.message || 'An error occurred');
      }
    }
  };

  return (
    <div className='wrapper'>
    <h1 className="portal-name">AI-Driven Internship Platform</h1>
      <div className="login-page">
      
        <div className="login-container" >
        <h1 className="welcome">Welcome Back!</h1>
            <form className="login-form" onSubmit={handleSubmit}>
              <label htmlFor="username">Username</label>
              <input 
                type="text" 
                id="username" 
                name="username" 
                placeholder="Enter your username"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required 
              />
              <label htmlFor="password">Password</label>
              <input 
                type="password" 
                id="password" 
                name="password" 
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
              <button type="submit" className="login-button">Login</button>
              <p className="signup-link">
                  Don't have an account? <span onClick={() => navigate('/register')}>Sign up</span>
              </p>
          </form>
          {error && <div className="error-message">{error}</div>}
        </div>
        <div className="image-container">
          <img src="/login-image.png" alt="Internship Platform" />
        </div>
    </div>
    </div>
  );
};

export default Login;
