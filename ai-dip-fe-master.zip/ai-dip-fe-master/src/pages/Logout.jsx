import React, { useEffect, useState } from 'react';
import { useNavigate } from "react-router-dom";
import axios from 'axios';

const Logout = () => {
  const navigate = useNavigate();
  const [error, setError] = useState('');

  useEffect(() => {
    const handleLogout = async () => {
      try {
        await axios.post('http://127.0.0.1:8000/api/logout/', {}, {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('accessToken')}`,
          },
        });

        // Clear the tokens from local storage
        localStorage.removeItem('accessToken');
        localStorage.removeItem('refreshToken');

        navigate('/login');
      } catch (error) {
        setError(error.response);
        if (error.response.status === 403) {
          navigate('/login');
        }
        console.error(error.message || 'An error occurred during logout');
      }
    };

    handleLogout();
  }, [navigate]);

  return (
    <div>
      {error ? (
        <div className="error-message">
          {error}
        </div>
        ) : (
        <div>
          Logging out...
        </div>
      )}
    </div>
  );
};

export default Logout;
