import React, { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { useLocation } from "react-router-dom";
import { useParams } from 'react-router-dom'
import LeftSide from "../components/LeftSide";
import TopSide from "../components/TopSide";
import "../style/index.css"
import "../style/Internship.css"


const InternshipOptions = () => {
  let optionID = useParams();
  const location = useLocation();
  const [userData, setUserData] = useState('');
  const [selectedOption, setSelectedOption] = useState(null);
  const { options } = location.state;
  const [error, setError] = useState('');
  const navigate = useNavigate();
    useEffect(() => {
      const fetchData = async () => {
        const token = localStorage.getItem('accessToken');
        try {
          const response = await axios.get("http://127.0.0.1:8000/api/home/", {
            headers: {
              Authorization: `Bearer ${token}`, // Include the token in the request headers
            },
          });
          if (response.status === 403) {
            navigate('/login');
          }
          setUserData(response.data);
          
        }
        catch (error) {
          setError(error.response);
          if (error.status === 403) {
            navigate('/login');
          }
        }
      };

      fetchData();
    }, [navigate]);

    if (!userData) {
      return <div>Loading...</div>;
    }

    const data = userData;
    const intern_option = options.filter(
      (option) => {
        if (String(option.id) === String(optionID.id)) {
          return option.title;
        } else {
          return null;
        }
      });
    
    var skills = options.filter(
      (option) => {
        if (option.title === intern_option[0].title) {
          return option.required_skills;
        }
        else {
          return null;
        }
      });

      const handleOptionChange = (event) => {
        setSelectedOption(event.target.value);
      };
    
      const handleSubmit = async (event) => {
        event.preventDefault();
        if (!selectedOption) {
          alert("Please select an option.");
          return;
        }
        
        const token = localStorage.getItem('accessToken');
        try {
          const response = await axios.post(
            `http://127.0.0.1:8000/api/internship/apply/${selectedOption}/`,
            {},
            {
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );
          if (response.status === 201) {
            alert("Applied successfully!");
            navigate('/internship/applied');
          } else if (response.status === 208) {
            alert("Already applied for this internship.");
          } else if (response.status === 204) {
            alert("User does not have the required skills.");
          } else if(response.status === 207) {
            alert("You have an incomplete internship.");
          }
        } catch (error) {
          console.error("Error applying for internship:", error);
          alert("An error occurred while applying for the internship.");
          setError(error.response);
          if (error.status === 403) {
            navigate('/login');
          }
        }
      };
    
  return (
    <div className="desktop-1">
    {error ? (
      <div className="error-message">
        {error}
      </div>
      ) : (
        <div className="dashboard-parent">
          <main className="dashboard">
            <section className="dashboard-child"></section>

            {/* Left Side Pannel */}
              <LeftSide Data={data} />

            {/* Top Side Pannel */}
            <TopSide />
            
            {/* Right Side Pannel */}
            <section className="main-content-wrapper">
              <div className="main-content">
                <div className="input-collector">
                  <div className="input-filter-parent">

                    {/* Internship Grid*/}
                    <div className="rectangle-parent30">
                      <div className="frame-child44" />
                      <div className="available-internships-wrapper">
                        <h1 className="available-internships">{intern_option[0].title}</h1>
                      </div>
                      <form onSubmit={handleSubmit}>
                      <div className="internships-grid">
                      {skills.map((option, index) => (
                        <div key={index} className="internships-grid-inner">
                        
                          <div className="rectangle-parent31">
                            <div className="frame-child45" />
                            <div className="wrapper5">
                              <div className="div9">0{index + 1}</div>
                            </div>
                            
                            <label htmlFor={`radio-${index}`}>
                            <div className="front-end-web-developer-wrapper">
                            {option.required_skills.map((re_skill, key) => (
                              <h5 key={key} className="front-end-web1">
                              {re_skill.skill_name +  `, `}
                              </h5>
                            ))}
                            </div>
                            </label>
                            <input 
                              type="radio" 
                              id={`radio-${index}`} 
                              value={option.id} 
                              name="skillRadio"
                              onChange={handleOptionChange}
                            />
                          </div>
                        </div>
                      ))}
                      </div>
                      <br />
                      <input type="submit" className="continue-button" value="Continue"></input>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </main>
        </div>
      )}
    </div>
  )
}
export default InternshipOptions;
