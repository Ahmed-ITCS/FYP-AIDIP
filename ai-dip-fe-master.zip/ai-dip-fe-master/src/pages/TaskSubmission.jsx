import React, { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom";
import { useLocation } from "react-router-dom";
import axios from "axios";
import LeftSide from "../components/LeftSide";
import TopSide from "../components/TopSide";
import "../style/index.css"
import "../style/Internship.css"


const TaskSubmission = () => {
  const [userData, setUserData] = useState('');
  const location = useLocation();
  const task = location.state;
  const [fileFields, setFileFields] = useState([{ fileLabel: "", fileCode: "" }]);
  const [error, setError] = useState('');
  const navigate = useNavigate();
    useEffect(() => {
      const fetchData = async () => {
        const token = localStorage.getItem('accessToken');
        try {
          const response = await axios.get("http://127.0.0.1:8000/api/home/", {
            headers: {
              Authorization: `Bearer ${token}`, // Include the token in the request headers
            },
          });
          if (response.status === 403) {
            navigate('/login');
          }
          setUserData(response.data);
          
        }
        catch (error) {
          setError(error.response);
          if (error.status === 403) {
            navigate('/login');
          }
        }
      };

      fetchData();
    }, [navigate]);

    const handleInputChange = (index, event) => {
      const { name, value } = event.target;
      const fields = [...fileFields];
      fields[index][name] = value;
      setFileFields(fields);
    };

    const addFileField = () => {
      setFileFields([...fileFields, { fileLabel: "", fileCode: "" }]);
    };

    const handleSubmit = async (event) => {
      event.preventDefault();
      try {
        let task_id;
        if (task.task.id === undefined) {
          task_id = task.task.task.id
        }
        else if (task.task.id !== null) {
          task_id = task.task.id
        }
        const token = localStorage.getItem('accessToken');
        const response = await axios.post(
          `http://127.0.0.1:8000/api/internship/submission/${task_id}/`,
          {
            fileLabel: fileFields.map((field) => field.fileLabel),
            fileCode: fileFields.map((field) => field.fileCode)
          },
          {
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`,
            },
          }
        );
  
        if (response.status === 200) {
          alert("Submission successful.");
          navigate('/internship')
        }
      } catch (error) {
        console.error("Submission error:", error);
        alert("An error occurred. Please try again.");
      }
    };
    
    if (!userData) {
      return <div>Loading...</div>;
    }
    const data = userData;
  return (
    <div className="desktop-1">
      {error ? (
        <div className="error-message">
          {error}
        </div>
        ) : (
        <div className="dashboard-parent">
          <main className="dashboard">
            <section className="dashboard-child"></section>

            {/* Left Side Pannel */}
              <LeftSide Data={data} />

            {/* Top Side Pannel */}
            <TopSide />
            
            {/* Right Side Pannel */}
            <section className="main-content-wrapper">
              <div className="main-content">
                <div className="input-collector">
                  <div className="input-filter-parent">
                    {/* Task Details Component */}
                    <div className="input-filter">
                      <div className="frame-parent20">
                        <div className="frame-parent21">
                          <div className="front-end-web-developer-parent">
                          </div>   
                          <div>
                            <h1>Solution Submission</h1>

                            <form id="codeForm" method="POST" onSubmit={handleSubmit}>
                              {fileFields.map((field, index) => (
                                <div key={index} className="file-input">
                                  <label htmlFor={`fileLabel${index}`}>File Name:</label>
                                  <input
                                    type="text"
                                    id={`fileLabel${index}`}
                                    name="fileLabel"
                                    value={field.fileLabel}
                                    onChange={(event) => handleInputChange(index, event)}
                                    required
                                  />
                                  <br />
                                  <br />
                                  <label htmlFor={`fileCode${index}`}>Code:</label>
                                  <br />
                                  <textarea
                                    id={`fileCode${index}`}
                                    name="fileCode"
                                    rows="6"
                                    cols="50"
                                    value={field.fileCode}
                                    onChange={(event) => handleInputChange(index, event)}
                                    required
                                  />
                                  <br />
                                  <br />
                                </div>
                              ))}
                              <button type="button" onClick={addFileField}>
                                Add File
                              </button>
                              <br />
                              <br />
                              <button type="submit">Submit</button>
                              <br />
                              <br />
                              <br />
                            </form>
                          </div> 
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </main>
        </div>
      )}
    </div>
  )
};
export default TaskSubmission;