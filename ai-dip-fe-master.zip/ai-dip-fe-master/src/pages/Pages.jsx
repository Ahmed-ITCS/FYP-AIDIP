import React, { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";

import Dashboard from "./Dashboard";
import Skills from "./Skills";
import Internship from "./Internship";
import Profile from "./Profile";
import Login from "./Login";
import AIManager from "./AIManager"
import Assessment from "./Assessment"
import AssessmentCheck from "./AssessmentCheck"
import Logout from "./Logout";
import AssessmentSubmission from "./AssessmentSubmission";
import InternshipOptions from "./InternshipOptions";
import Applied from "./Applied";
import NotQualified from "./NotQualified";
import InternshipTask from "./InternshipTask";
import TaskSubmission from "./TaskSubmission";
import ProfileUpdate from "./ProfileUpdate";
import Register from "./Register";
import CreateProfile from "./CreateProfile";
import OrgHome from "./OrgHome";
import CandidateProfile from "./CandidateProfile";
import SendOffer from "./SendOffer";
import OrgRegister from "./OrgRegister";
import OrgLogin from "./OrgLogin";
import OrgCreateProfile from "./OrgCreateProfile";
import OrgLogout from "./OrgLogout";
import AcceptedOffers from "./AcceptedOffers";
import SendedOffers from "./SendedOffers";
import Offers from "./Offers";
import MainPage from "./MainPage";

const Pages = () => {
    const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "AI-DIP Dashboard";
        metaDescription = "";
        break;
      case "/dashboard":
      title = "Dashboard";
      metaDescription = "";
      break;
      case "/skills":
        title = "skills";
        metaDescription = "";
        break;
      case "/internship":
        title = "internship";
        metaDescription = "";
        break;
      case "/profile":
        title = "profile";
        metaDescription = "";
        break;
      case "/ai-manager":
        title = "AI Manager";
        metaDescription = "";
        break;
      case "/login":
        title = "login";
        metaDescription = "";
        break;
      case "/assessment":
        title = "assessment";
        metaDescription = "";
        break;
      case "/assessment-check":
        title = "assessment-check";
        metaDescription = "";
        break;
      case "/assessment-submission":
        title = "assessment-submission";
        metaDescription = "";
        break;
      default:
        title = "";
        metaDescription = "";
    }
    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);
  
    return (
        <Routes>
            <Route path="/" element={<MainPage />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/skills" element={<Skills />} />
            <Route path="/ai-manager" element={<AIManager />} />
            <Route path="/internship" element={<Internship />} />
            <Route path="/internship/option/:id" element={<InternshipOptions />} />
            <Route path="/internship/applied" element={<Applied />} />
            <Route path="/internship/not-qualified" element={<NotQualified />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/login" element={<Login />} />
            <Route path="/assessment/:id" element={<Assessment />} />
            <Route path="/assessment-check/:id/" element={<AssessmentCheck />} />
            <Route path="/logout" element={<Logout />} />
            <Route path="/assessment-submission/" element={<AssessmentSubmission />} />
            <Route path="/internship/task/:id" element={<InternshipTask />} />
            <Route path="/internship/task-submission/:id" element={<TaskSubmission />} />
            <Route path="/settings" element={<ProfileUpdate />} />
            <Route path="/register" element={<Register />} />
            <Route path="/create-profile" element={<CreateProfile />} />
            <Route path="/offers" element={<Offers />} />

            <Route path="/org/home" element={<OrgHome />} />
            <Route path="/org/candidate/:id" element={<CandidateProfile />} />
            <Route path="/org/send-offer" element={<SendOffer />} />
            <Route path="/org/register" element={<OrgRegister />} />
            <Route path="/org/login" element={<OrgLogin />} />
            <Route path="/org/create-profile" element={<OrgCreateProfile />} />
            <Route path="/org/logout" element={<OrgLogout />} />
            <Route path="/org/accepted-offers" element={<AcceptedOffers />} />
            <Route path="/org/sended-offers" element={<SendedOffers />} />
      </Routes>
    )
};
export default Pages