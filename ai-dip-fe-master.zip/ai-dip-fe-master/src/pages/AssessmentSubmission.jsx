import React, { useEffect, useState } from "react"
import { NavLink,useNavigate } from "react-router-dom";
import axios from "axios";
import LeftSide from "../components/LeftSide";
import TopSide from "../components/TopSide";
import "../style/index.css"
import "../style/Internship.css"
import "../style/AssessmentCheck.css"


const AssessmentSubmission = () => {
    const [userData, setUserData] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();
    useEffect(() => {
      const fetchData = async () => {
        const token = localStorage.getItem('accessToken');
        try {
          const response = await axios.get("http://127.0.0.1:8000/api/home/", {
            headers: {
              Authorization: `Bearer ${token}`, // Include the token in the request headers
            },
          });
          if (response.status === 403) {
            navigate('/login');
          }
          setUserData(response.data);
          
        }
        catch (error) {
          setError(error.response);
          if (error.status === 403) {
            navigate('/login');
          }
        }
      };

      fetchData();
    }, [navigate]);

    console.log(error)

    if (!userData) {
      return <div>Loading...</div>;
    }

    const data = userData;
  return (
    <div className="desktop-1">
      <div className="dashboard-parent">
        <main className="dashboard">
            <section className="dashboard-child"></section>

            {/* Left Side Pannel */}
            <LeftSide Data={data} />

            {/* Top Side Pannel */}
            <TopSide />
            
            {/* Right Side Pannel */}
            <section className="main-content-wrapper">
            <div className="main-content">
            <div className="assessment-check">
                <h2>Assessment Submit Successfully</h2>
                <p>
                  Your answers submitted successfully. It will take some time for the evaluation and after the evaluation you will get the socre of this skill.
                  For now you can proceed with others skills.
                </p>
                <NavLink to={'/skills'}>
                    <div className="continue-button">Continue</div>
                </NavLink>
            </div>
            </div>
        </section>
        
        </main>
      </div>
    </div>
  )
}
export default AssessmentSubmission;