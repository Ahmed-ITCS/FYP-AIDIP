import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import LeftSide from "../components/LeftSide";
import TopSide from "../components/TopSide";
import "../style/index.css";
import "../style/AIManager.css";

const AIManager = () => {
  const [userData, setUserData] = useState({ profile: { first_name: "", last_name: ""}});
  const [conversations, setConversations] = useState([]); // Ensure this is an array
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      const token = localStorage.getItem('accessToken');
      try {
        const response = await axios.get("http://127.0.0.1:8000/api/home/", {
          headers: {
            Authorization: `Bearer ${token}`, // Include the token in the request headers
          },
        });
        if (response.status === 403) {
          navigate('/login');
        }
        setUserData(response.data);
      } catch (error) {
        if (error.response && error.response.status === 403) {
          navigate('/login');
        }
        setError(error.message);
      }
    };

    const fetchConversations = async () => {
      const token = localStorage.getItem('accessToken');
      try {
        const response = await axios.get("http://127.0.0.1:8000/api/manager/", {
          headers: {
            Authorization: `Bearer ${token}`, // Include the token in the request headers
          },
        });
        if (response.status === 204) {
          alert('Internship is not yet started. Please wait for the internship to start.')
          navigate('/');
        }
        if (Array.isArray(response.data)) {
          setConversations(response.data);
        } else {
          setConversations([]);
        }
      } catch (error) {
        if (error.response && error.response.status === 403) {
          navigate('/login');
        }
        setError(error.message);
      }
    };

    fetchData();
    fetchConversations();
  }, [navigate]);

  const handleInputChange = (e) => {
    setMessage(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem('accessToken');
    try {
      const response = await axios.post("http://127.0.0.1:8000/api/manager/", 
        { message }, 
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      const newConversation = response.data;
      setConversations([...conversations, newConversation]);

      // Clear the message input
      setMessage('');
    } catch (error) {
      if (error.response && error.response.status === 403) {
        navigate('/login');
      }
      setError(error.message);
    }
  };



  const data = userData;
  
  return (
    <div className="desktop-1">
      {error ? (
        <div className="error-message">
          {error}
        </div>
        ) : (
          <div className="dashboard-parent">
            <main className="dashboard">
              <section className="dashboard-child"></section>

              {/* Left Side Pannel */}
                <LeftSide Data={data} />

              {/* Top Side Pannel */}
              <TopSide />
              
              {/* Right Side Pannel */}
              <div className="rectangle-parent72">
              
              <div className="conversation">
              <div className="chat-container">
                    <div className="rectangle-parent73">
                      <div className="frame-child103" />
                        <div className="manager">Manager</div>
                      <div className="introduction">
                        <div className="hello-i-am-container">
                          <p className="i-am-your">
                            Hello, <br /> I am your AI Manager. How can I help you today?
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <br />
              {conversations.map((conversation, index) => (
                <div key={index}>
                  <div className="user-query">
                    <div className="rectangle-parent74">
                      <div className="frame-child104" />
                      <div className="i-am-facing">
                        {conversation.message}
                      </div>
                    </div>
                  </div>
                  <br />
                  <div className="chat-container">
                    <div className="rectangle-parent73">
                      <div className="frame-child103" />
                        <div className="manager">Manager</div>
                      <div className="introduction">
                        <div className="hello-i-am-container">
                          <p className="i-am-your">
                            {conversation.response}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <br />
                </div>
                
              ))}
              </div>
                <div className="call-to-action">
                  <div className="rectangle-parent76">
                    <div className="frame-child106" />
                    <input 
                      className="ask-me" 
                      placeholder="Ask me....." 
                      type="text" 
                      value={message}
                      onChange={handleInputChange}
                    />
                    <div className="vector-wrapper1">
                      <img 
                        className="frame-child107" 
                        alt="" 
                        src="/rectangle-6557.svg" 
                        onClick={handleSubmit}
                      />
                    </div>
                  </div>
                </div>
              </div>
              
            </main>
          </div>
        )}
      
    </div>
  )
}
export default AIManager;