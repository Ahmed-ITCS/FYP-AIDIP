import React from 'react'
import { useLocation, NavLink } from 'react-router-dom';
import OrgNavbar from '../components/OrgNavbar';


const CandidateProfile = () => {
    const location = useLocation();
    const { candidate } = location.state;
    return(
        <div className='org-home'>
            <link 
                rel="stylesheet" 
                href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" 
                integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" 
                crossOrigin="anonymous"
            /> 
            <OrgNavbar />
            <div className="page-content p-5" id="content" style={{width: '100%'}}>
            {candidate ? (
                    <div className="personal-profile-parent" style={{marginTop: '10px', marginLeft: '0px'}}>
                    <div className="personal-profile">
                        <div className="frame-parent31" >
                        <div className="profile-wrapper1">
                            <img
                            className="profile-icon"
                            loading="lazy"
                            alt=""
                            src={candidate.profile_photo ? (`http://127.0.0.1:8000/${candidate.profile_photo}`) : ('/default-profile-photo.jpg')}
                            />
                        </div>
                        {/* <div className="frame-child63" /> */}
                        <div className="hunain-baloch-parent" >
                            <h1 className="hunain-baloch2">{candidate.first_name} {candidate.last_name}</h1>
                            <div className="talent-pakistan-icon-parent">
                            <div className="talent-pakistan-icon" >
                                <div className="talent">{candidate.category}</div>
                                <div className="talent-pakistan-icon-inner">
                                <div className="frame-child64" />
                                </div>
                                <div className="pakistan">Pakistan</div>
                            </div>
                            <div className="frame-wrapper23">
                                <button className="rectangle-parent47">
                                <div className="frame-child65" />
                                <div className="frame-wrapper24">
                                    <img className="frame-child66" alt="" src="/group-40246.svg" />
                                </div>
                                <div className="available">Available</div>
                                </button>
                            </div>
                            </div>
                            <div className="frame-wrapper25">
                            <div className="skill-score-parent">
                                <div className="skill-score">
                                <span>{candidate.skill_score || '0'}</span>
                                <span className="skill-score1"> Skill Score</span>
                                </div>
                                <div className="frame-child67" />
                                <div className="frame-child67-1" style={{width: `100%`}}/>
                            </div>
                            <div className="frame-child68" />
                            </div>
                        </div>
                        <NavLink to={'/org/send-offer'} state={{candidate}}>
                        <button 
                            className="btn btn-outline-danger my-2 my-sm-0" 
                            type="submit" 
                            style={{marginLeft: '380px'}}
                            >Send Offer</button>
                        </NavLink>
                        </div>
                        
                    </div>
                    <div className="frame-parent32">
                        <div className="frame-parent33">
                        <div className="skill-score-wrapper">
                            <b className="skill-score2">Skill Score</b>
                        </div>
                        <div className="overall-parent">
                            <div className="overall">Overall</div>
                            <div className="frame-parent34">
                            <div className="frame-wrapper26">
                                <div className="rectangle-parent48">
                                <div className="frame-child69" />
                                <div className="frame-child70" style={{width: `${candidate.skill_score / candidate.user_skills.length}%`}} />
                                </div>
                            </div>
                            <div className="div12">{(candidate.skill_score / candidate.user_skills.length).toFixed(0) || '0'}%</div>
                            </div>
                        </div>
                        {candidate.user_skills.length > 0 && candidate.user_skills.map( (skill, index) => (
                            <div key={index} className="python-parent">
                            <div className="python">{skill.skill.skill_name}</div>
                            <div className="frame-parent35">
                                <div className="frame-wrapper27">
                                <div className="rectangle-parent49">
                                    <div className="frame-child71" />
                                    <div className="frame-child72" style={{width: `${skill.score}%`}}/>
                                </div>
                                </div>
                                <div className="div13">{skill.score}%</div>
                            </div>
                            </div>
                        ))}
                        <div className="frame-child77" />
                        </div>

                        <div>
                        <div className="software-engineer-parent">
                            <h2 className="software-engineer">{candidate.category}</h2>
                            <div className="full-stack-developer-title">
                            <div className="passionate-full-stack">
                                {candidate.bio}
                            </div>
                            </div>
                        </div>
                        <div className="software-engineer-parent">
                            <div className="profile-detail">Education</div>
                            <div className="expertise-parent">
                            <b className="expertise">University</b>
                            <b className="python-django">{candidate.university_name}</b>
                            </div>
                            <div className="expertise-parent">
                            <b className="expertise">Degree</b>
                            <b className="python-django">{candidate.degree_name}</b>
                            </div>
                            <div className="expertise-parent">
                            <b className="expertise">Graducation Year</b>
                            <b className="python-django">{candidate.graduation_year}</b>
                            </div>
                        </div>
                            
                        </div>  
                    </div>
                    </div>
                    ) : (
                        <p>Loading candidate...</p>
                    )}
            </div>
        </div>
    )
};
export default CandidateProfile;
