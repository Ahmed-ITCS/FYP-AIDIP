import React, { useEffect, useState, useRef } from "react"
import { NavLink, useNavigate } from "react-router-dom";
import axios from "axios";
import LeftSide from "../components/LeftSide";
import TopSide from "../components/TopSide";
import "../style/index.css"
import "../style/Internship.css"


const Internship = () => {
  const [userData, setUserData] = useState({ profile: { first_name: "", last_name: ""}});
  const [options, setOptions] = useState([]);
  const [selectedOption, setSelectedOption] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [intern_option, setInternOption] = useState([]);
  const prevTasksRef = useRef();
  const prevOptionsRef = useRef();
  const navigate = useNavigate();
  
    useEffect(() => {
      const fetchData = async () => {
        const token = localStorage.getItem('accessToken');
        try {
          const response = await axios.get("http://127.0.0.1:8000/api/home/", {
            headers: {
              Authorization: `Bearer ${token}`, // Include the token in the request headers
            },
          });
          if (response.status === 403) {
            navigate('/login');
          }
          setUserData(response.data);
          
        }
        catch (error) {
          
          if (error.response.status === 403) {
            navigate('/login');
          }
        }
      };

      fetchData();
    }, [navigate]);

    useEffect(() => {
      const fetchOptions = async () => {
        const token = localStorage.getItem('accessToken');
        try {
          const response = await axios.get("http://127.0.0.1:8000/api/internship-options/", {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });
          
          setOptions(response.data);
        } catch (error) {
          
          if (error.response.status === 403) {
            navigate('/login');
          }
        }
      };

      fetchOptions();
    }, [navigate]);

    useEffect(() => {
      const fetchTasks = async () => {
        const token = localStorage.getItem('accessToken');
        try {
          const task_response = await axios.get("http://127.0.0.1:8000/api/internship/task/", {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });
          if (task_response.status === 403) {
            navigate('/login');
          }
          if (task_response.status === 200) {
            setTasks(task_response.data);
          }
          if (task_response.status === 204) {
            setTasks([])
          }
        } catch (error) {
          
          if (error.response.status === 403) {
            navigate('/login');
          }
        }
      };

      fetchTasks();
    }, [navigate]);

    useEffect(() => {
      const prevTasks = prevTasksRef.current;
      const prevOptions = prevOptionsRef.current;
    
      if (tasks.length > 0 && (prevTasks !== tasks || prevOptions !== options)) {
        const matchedOption = options.find(option => option.id === tasks[0].internship_option);
        if (matchedOption) {
          setInternOption(matchedOption.title);
        } else {
          console.log('No matching option found');
        }
      }
    
      prevTasksRef.current = tasks;
      prevOptionsRef.current = options;
    }, [tasks, options]);

    useEffect(() => {
      const prevOptions = prevOptionsRef.current;

      if (options.length > 0 || prevOptions !== options) {
        const uniqueOptions = Array.from(
          new Map(options.map((option) => [option.title, option])).values()
        );
        setSelectedOption(uniqueOptions);
      }

      prevOptionsRef.current = options;
    }, [options]);
  
    const formatDateTime = (dateTimeString) => {
      const date = new Date(dateTimeString);
      const year = date.getFullYear();
      const month = date.getMonth() + 1;
      const day = date.getDate();
      const hours = date.getHours();
      const minutes = date.getMinutes().toString().padStart(2, '0');
      return `${day}/${month}/${year} ${hours}:${minutes}`;
    };

    const data = userData;
  return (
    <div className="desktop-1">
       <div className="dashboard-parent">
            <main className="dashboard">
              <section className="dashboard-child"></section>

              {/* Left Side Pannel */}
                <LeftSide Data={data} />

              {/* Top Side Pannel */}
              <TopSide />
              
              {/* Right Side Pannel */}
              <section className="main-content-wrapper">
                <div className="main-content">
                  <div className="input-collector">
                    <div className="input-filter-parent">
                      {/* Task Details Component */}
                      {tasks.length > 0 && (
                      <div className="input-filter">
                        <div className="frame-parent20">
                          <div className="frame-parent21">
                            <div className="front-end-web-developer-parent">
                              <h3 className="front-end-web">{intern_option}</h3>
                              <div className="internship">Internship</div>
                            </div>

                            {tasks.map((task, index) => (                          
                              <div key={index} className="rectangle-parent24">
                              <div className="frame-child35" />
                              <div className="module-01">Task 0{task.id}</div>
                              <div className="frame-wrapper14">
                                <div className="frame-parent22">
                                  <div className="frame-parent23">
                                    <div className="duration-4-days-parent">
                                      <div className="duration-4-days">Complexity: Medium</div>
                                      <div className="task-details-parent">
                                      <NavLink to={`/internship/task/${task.id}/`} state={{ task }}>
                                        <div className="task-details">Task Details</div>
                                        <div className="vector-wrapper">
                                          <img
                                            className="frame-child36"
                                            alt=""
                                            src="/vector-647.svg"
                                          />
                                        </div>
                                        </NavLink>
                                      </div>
                                    </div>
                                    <div className="deadline-10022024">
                                      Deadline: {formatDateTime(task.submission_deadline)}
                                    </div>
                                  </div>
                                  {(task.task_completed === false) && (
                                    <NavLink to={`/internship/task-submission/${task.id}/`} state={{ task }}>
                                    <button className="rectangle-parent25">
                                      <div className="frame-child37" />
                                        <div className="completed" style={{textDecoration: 'none'}}>Upload</div>
                                    </button>
                                    </NavLink>
                                  )}
                                  {(task.task_completed === true) && (
                                    <button className="rectangle-parent25">
                                      <div className="frame-child37" />
                                        <div className="completed" >Completed</div>
                                    </button>
                                  )}
                                </div>
                              </div>
                            </div>
                            ))}

                          </div>
                        </div>
                      </div>
                      )}
                      {/* Internship Grid */}
                      
                      <div className="rectangle-parent30">
                        <div className="frame-child44" />
                        <div className="available-internships-wrapper">
                          <h1 className="available-internships">Available Internships</h1>
                        </div>
                        <div className="internships-grid">
                        {selectedOption.map((option, index) => (
                          <div key={index} className="internships-grid-inner">
                            <div className="rectangle-parent31">
                              <div className="frame-child45" />
                              <div className="wrapper5">
                                <div className="div9">0{index + 1}</div>
                              </div>
                              <div className="front-end-web-developer-wrapper">
                                <h3 className="front-end-web1">{option.title}</h3>
                              </div>
                              <NavLink to={`/internship/option/${option.id}/`} state={{ options }}>
                              <div className="input-processor-parent">
                                <div className="input-processor" />
                                <img
                                  className="output-handler-icon"
                                  loading="lazy"
                                  alt=""
                                  src="/vector-646.svg"
                                />
                              </div>
                              </NavLink>
                            </div>
                          </div>
                        ))}
                        </div>
                      </div>
                      
                    </div>
                  </div>
                </div>
              </section>
            </main>
          </div>
    </div>
  )
}
export default Internship;

