import React, { useEffect, useState } from "react"
import { NavLink,useNavigate } from "react-router-dom";
import axios from "axios";
import LeftSide from "../components/LeftSide";
import TopSide from "../components/TopSide";
import { useLocation } from 'react-router-dom';
import "../style/index.css"
import "../style/Internship.css"
import "../style/AssessmentCheck.css"


const AssessmentCheck = () => {
    const location = useLocation();
    const { skill } = location.state;
    const [userData, setUserData] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();
    useEffect(() => {
      const fetchData = async () => {
        const token = localStorage.getItem('accessToken');
        try {
          const response = await axios.get("http://127.0.0.1:8000/api/home/", {
            headers: {
              Authorization: `Bearer ${token}`, // Include the token in the request headers
            },
          });
          if (response.status === 403) {
            navigate('/login');
          }
          setUserData(response.data);
          
        }
        catch (error) {
          setError(error.response);
          if (error.status === 403) {
            navigate('/login');
          }
        }
      };

      fetchData();
    }, [navigate]);

    

    if (!userData) {
      return <div>Loading...</div>;
    }

    const data = userData;
  return (
    <div className="desktop-1">
      <div className="dashboard-parent">
      {error && <div className="error">{error}</div>}
        <main className="dashboard">
            <section className="dashboard-child"></section>

            {/* Left Side Pannel */}
            <LeftSide Data={data} />

            {/* Top Side Pannel */}
            <TopSide />
            
            {/* Right Side Pannel */}
            <section className="main-content-wrapper">
            <div className="main-content">
            <div className="assessment-check">
                <h1>Assessment Instruction</h1>
                <p>Skill: <strong>{skill.skill_name}</strong></p>
                <p>Time: <strong>15 minutes</strong></p>
                <p>Passing Marks: <strong>60%</strong></p>
                <p>Number of Questions: <strong>10</strong></p>
                <p>Number of Attempts: <strong>Only 01</strong></p>
                <p>Test Result: <strong>Instant</strong></p>
                <p>Test Retake: <strong>After 30 days</strong></p>
                <h3>Skill Description:</h3>
                <p>{skill.skill_description}</p>
                <h3>Instructions:</h3>
                <div className="instruction">
                    <p>If you want to add this skill to your profile, you have to pass the skill assessment test. The test will be conducted in an isolated environment within a limited time.</p>
                    <p>Once the test starts you have to complete it within the given time and you are not able to pause it. You have to obtain at least 60% marks in the test to pass it.</p>
                    <p>If you fail to obtain 60% marks then you can retake the test after 30 days.</p>
                    <p>Once you click on the continue button the countdown of 15 minutes will be started which is the time of the test and you have to complete and submit the test within that time.</p>
                </div>
                <NavLink to={`/assessment/${skill.id}/`} state={{ skill }}>
                    <div className="continue-button">Continue</div>
                </NavLink>
            </div>
            </div>
        </section>
        
        </main>
      </div>
    </div>
  )
}
export default AssessmentCheck;