import React, { useState, useEffect } from 'react';
import { NavLink, useNavigate } from "react-router-dom";
import axios from "axios";
import LeftSide from "../components/LeftSide";
import TopSide from "../components/TopSide";
import "../style/index.css";
import "../style/Profile.css";

const Profile = () => {
  const [profile, setProfile] = useState(null);
  const [error, setError] = useState('');
  const [userData, setUserData] = useState({ profile: { first_name: "John", last_name: "Sign"}});
  const [skills, setSkills] = useState([]);
  const [skillScore, setSkillScore] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      const token = localStorage.getItem('accessToken');
      try {
        const response = await axios.get("http://127.0.0.1:8000/api/home/", {
          headers: {
            Authorization: `Bearer ${token}`, // Include the token in the request headers
          },
        });
        if (response.status === 403) {
          navigate('/login');
        }
        setUserData(response.data);
        setProfile(response.data.profile);
        
      }
      catch (error) {
        setError(error.response);
          if (error.status === 403) {
            navigate('/login');
          }
      }
    };

    fetchData();
  }, [navigate]);

  useEffect(() => {
    const token = localStorage.getItem('accessToken');
    if (!token) {
      navigate('/login');
    }
    const fetchSkills = async () => {
      try {
        const response = await axios.get("http://127.0.0.1:8000/api/user-skills/", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        if (response.status === 403) {
          navigate('/login');
        }
        setSkills(response.data);
      } catch (error) {
        setError(error.response);
        if (error.status === 403) {
          navigate('/login');
        }
      }
    };

    fetchSkills();
  }, [navigate]);

  useEffect(() => {
    if (skills.length > 0) {
      const totalScore = skills.reduce((acc, skill) => acc + skill.score, 0);
      const averageScore = Math.round(totalScore / skills.length);
      setSkillScore(averageScore);
    }
  }, [skills]);

  const data = userData;

  return (
    <div className="desktop-1">
      {error ? (
        <div className="error-message">
          {error}
        </div>
        ) : (
        <div className="dashboard-parent">
          <main className="dashboard">
            <section className="dashboard-child"></section>

            {/* Left Side Pannel */}
              <LeftSide Data={data} />

            {/* Top Side Pannel */}
            <TopSide />
            
            {/* Right Side Pannel */}
            {profile ? (
            <div className="personal-profile-parent">
              <div className="personal-profile">
                <div className="frame-parent31">
                  <div className="profile-wrapper1">
                    <img
                      className="profile-icon"
                      loading="lazy"
                      alt=""
                      src={profile.profile_photo ? (`http://127.0.0.1:8000/${profile.profile_photo}`) : ('/default-profile-photo.jpg')}
                    />
                  </div>
                  {/* <div className="frame-child63" /> */}
                  <div className="hunain-baloch-parent">
                    <h1 className="hunain-baloch2">{profile.first_name} {profile.last_name}</h1>
                    <div className="talent-pakistan-icon-parent">
                      <div className="talent-pakistan-icon">
                        <div className="talent">{profile.category}</div>
                        <div className="talent-pakistan-icon-inner">
                          <div className="frame-child64" />
                        </div>
                        <div className="pakistan">Pakistan</div>
                      </div>
                      <div className="frame-wrapper23">
                        <button className="rectangle-parent47">
                          <div className="frame-child65" />
                          <div className="frame-wrapper24">
                            <img className="frame-child66" alt="" src="/group-40246.svg" />
                          </div>
                          <div className="available">Available</div>
                        </button>
                      </div>
                    </div>
                    <div className="frame-wrapper25">
                      <div className="skill-score-parent">
                        <div className="skill-score">
                          <span>{skillScore || '0'}%</span>
                          <span className="skill-score1"> Skill Score</span>
                        </div>
                        <div className="frame-child67" />
                        <div className="frame-child67-1" style={{width: `${skillScore}%`}}/>
                      </div>
                      <div className="frame-child68" />
                    </div>
                  </div>
                  
                </div>
              </div>
              <div className="frame-parent32">
                <div className="frame-parent33">
                  <div className="skill-score-wrapper">
                    <b className="skill-score2">Skill Score</b>
                  </div>
                  <div className="overall-parent">
                    <div className="overall">Overall</div>
                    <div className="frame-parent34">
                      <div className="frame-wrapper26">
                        <div className="rectangle-parent48">
                          <div className="frame-child69" />
                          <div className="frame-child70" style={{width: `${skillScore}%`}} />
                        </div>
                      </div>
                      <div className="div12">{skillScore || '0'}%</div>
                    </div>
                  </div>
                  {skills.length > 0 && skills.map( (skill, index) => (
                    <div key={index} className="python-parent">
                      <div className="python">{skill.skill.skill_name}</div>
                      <div className="frame-parent35">
                        <div className="frame-wrapper27">
                          <div className="rectangle-parent49">
                            <div className="frame-child71" />
                            <div className="frame-child72" style={{width: `${skill.score}%`}}/>
                          </div>
                        </div>
                        <div className="div13">{skill.score}%</div>
                      </div>
                    </div>
                  ))}
                    <NavLink to={'/skills'}>
                    <button className="take-a-test-parent" >
                      <div className="take-a-test" >Take a Test</div>
                      <div className="frame-child76" />
                    </button>
                    </NavLink>
                  <div className="frame-child77" />
                </div>

                <div>
                  <div className="software-engineer-parent">
                    <h2 className="software-engineer">{profile.category}</h2>
                    <div className="full-stack-developer-title">
                      <div className="passionate-full-stack">
                        {profile.bio}
                      </div>
                    </div>
                  </div>
                  <div className="software-engineer-parent">
                    <div className="profile-detail">Personal Detail</div>
                    <div className="expertise-parent">
                      <b className="expertise">Email</b>
                      <b className="python-django">{data.user.email}</b>
                    </div>
                    <div className="expertise-parent">
                      <b className="expertise">Phone Number</b>
                      <b className="python-django">{profile.phone_number}</b>
                    </div>
                  </div>
                  <div className="software-engineer-parent">
                    <div className="profile-detail">Education</div>
                    <div className="expertise-parent">
                      <b className="expertise">University</b>
                      <b className="python-django">{profile.university_name}</b>
                    </div>
                    <div className="expertise-parent">
                      <b className="expertise">Degree</b>
                      <b className="python-django">{profile.degree_name}</b>
                    </div>
                    <div className="expertise-parent">
                      <b className="expertise">Graducation Year</b>
                      <b className="python-django">{profile.graduation_year}</b>
                    </div>
                  </div>
                    
                </div>  
              </div>
            </div>
            ) : (
                <p>Loading profile...</p>
            )}
            
          </main>
        </div>
      )}
    </div>
  )
}
export default Profile;
