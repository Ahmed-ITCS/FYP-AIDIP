import React, { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom";
import axios from "axios";
import LeftSide from "../components/LeftSide";
import TopSide from "../components/TopSide";
import "../style/index.css"
import "../style/Internship.css"


const Offers = () => {
  const [userData, setUserData] = useState({ profile: { first_name: "", last_name: ""}});
  const [details, setDetails] = useState(null);
  const [offers, setOffers] = useState([]);
  const [interest, setInterest] = useState({});
  const navigate = useNavigate();
  
    useEffect(() => {
      const fetchData = async () => {
        const token = localStorage.getItem('accessToken');
        try {
          const response = await axios.get("http://127.0.0.1:8000/api/home/", {
            headers: {
              Authorization: `Bearer ${token}`, // Include the token in the request headers
            },
          });
          if (response.status === 403) {
            navigate('/login');
          }
          setUserData(response.data);
          
        }
        catch (error) {
          
          if (error.response.status === 403) {
            navigate('/login');
          }
        }
      };

      fetchData();
    }, [navigate]);

    useEffect(() => {
        const fetchOffers = async () => {
          const token = localStorage.getItem('accessToken');
          try {
            const response = await axios.get("http://127.0.0.1:8000/api/offers/", {
              headers: {
                Authorization: `Bearer ${token}`, // Include the token in the request headers
              },
            });
            if (response.status === 403) {
              navigate('/login');
            }
            setOffers(response.data);
          }
          catch (error) {
            
            if (error.response.status === 403) {
              navigate('/login');
            }
          }
        };
  
        fetchOffers();
      }, [navigate]);

      const handelSubmitTrue = async (details) => {
        setInterest({
            ...interest,
            'id': details.id,
            'accepted': 1
        })
        console.log('interst', interest)
        const token = localStorage.getItem('accessToken');
        try {
            const response = await axios.patch('http://127.0.0.1:8000/api/offers/', {interest}, {
                headers: {
                    Authorization: `Bearer ${token}`, // Include the token in the request headers
                  },
            });
            if (response.status === 200) {
                alert('Response submit successfully.')
                navigate('/offers')
                window.location.reload(false);
            }
            else if (response.status === 304) {
                alert('Response not submitted. Please try agian later')
                navigate('/offers')
                window.location.reload(false);
            }
        } catch (error) {
            if (error.response.status === 403) {
                navigate('/org/login')
            }
        }
      }

      const handelSubmitFlase = async (details) => {
        setInterest({
            ...interest,
            'id': details.id,
            'rejected': 1
        })
        console.log('interst', interest)
        const token = localStorage.getItem('accessToken');
        try {
            const response = await axios.patch('http://127.0.0.1:8000/api/offers/', {interest}, {
                headers: {
                    Authorization: `Bearer ${token}`, // Include the token in the request headers
                  },
            });
            if (response.status === 200) {
                alert('Response submit successfully.')
                navigate('/offers')
                window.location.reload(false);
            }
            else if (response.status === 304) {
                alert('Response not submitted. Please try agian later')
                navigate('/offers')
                window.location.reload(false);
            }
        } catch (error) {
            if (error.response.status === 403) {
                navigate('/org/login')
            }
        }
      }

    const data = userData;
  return (
    <div className="desktop-1">
       <div className="dashboard-parent">
            <main className="dashboard">
              <section className="dashboard-child"></section>

              {/* Left Side Pannel */}
                <LeftSide Data={data} />

              {/* Top Side Pannel */}
              <TopSide />
              
              {/* Right Side Pannel */}
              <section className="main-content-wrapper">
                <div className="main-content">
                  <div className="input-collector">
                    <div className="input-filter-parent">
                      {/* Task Details Component */}
                        
                      <div className="input-filter">
                        <div className="frame-parent20">
                          <div className="frame-parent21">
                            <div className="front-end-web-developer-parent">
                              <h3 className="front-end-web">Offers From Companies</h3>
                            </div>
                            {offers.length > 0 && (
                            <div>
                            {offers.map((offer, index) => (                          
                              <div key={index} className="rectangle-parent24">
                              <div className="frame-child35" />
                              <div className="module-01">Offer 0{index + 1}</div>
                              <div className="frame-wrapper14">
                                <div className="frame-parent22">
                                  <div className="frame-parent23">
                                    <div className="duration-4-days-parent">
                                        <div className="duration-4-days">Job Title: {offer.title}</div>
                                        <div className="task-details-parent">
                                            <div className="task-details">Company: {offer.company_name}</div>
                                        </div>
                                    </div>
                                    <div className="deadline-10022024">
                                      Location: {offer.location}
                                    </div>
                                    <button 
                                        className="rectangle-parent25"
                                        onClick={() => {setDetails(offer)}}>
                                        Details
                                    </button>
                                  </div>
                                </div>
                              </div>
                            </div>
                            ))}
                        </div>
                    ) || (
                        <div>No Offer Found</div>
                    )}
                          </div>
                        </div>
                      </div>
                      
                      
                      {/* Offer Details */}
                      {details === null ? (<div></div>) : (
                        <div className="rectangle-parent30">
                            <div className="frame-child44" />
                            <div className="available-internships-wrapper">
                                <h1 className="available-internships">Company: {details.company_name}</h1>
                                <button 
                                    className="rectangle-parent25"
                                    style={{marginLeft: '10px', backgroundColor: 'green', color: 'white'}}
                                    onClick={() => { handelSubmitTrue(details)}}
                                    >Interest</button> 
                                <button 
                                    className="rectangle-parent25" 
                                    style={{marginLeft: '10px', backgroundColor: 'red', color: 'white'}}
                                    onClick={() => {handelSubmitFlase(details) }}
                                    >Not Interest</button>
                            </div>
                            <div className="internships-grid">
                                <h3 className="front-end-web1">Job Title: {details.title}</h3>
                                <h3 className="front-end-web1">Location: {details.location}</h3>
                                <h3 className="front-end-web1">Expected Salary: {details.salary}</h3>
                                <h3 className="front-end-web1">Job Description: {details.description}</h3>
                            </div>
                        </div>
                      )}
                    </div> 
                  </div>
                </div>
              </section>
            </main>
          </div>
    </div>
  )
}
export default Offers;

