import React, { useEffect, useState } from "react"
import { NavLink, useNavigate } from "react-router-dom";
import { useLocation } from "react-router-dom";
import axios from "axios";
import LeftSide from "../components/LeftSide";
import TopSide from "../components/TopSide";
import "../style/index.css"
import "../style/Internship.css"


const InternshipTask = () => {
  const [userData, setUserData] = useState('');
  const location = useLocation();
  const task = location.state;
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const [projectTitle, setProjectTitle] = useState('');
  const [briefIntroduction, setBriefIntroduction] = useState('');
  const [objectives, setObjectives] = useState([]);
  const [requirements, setRequirements] = useState([]);
  const [additionalResources, setAdditionalResources] = useState([]);
  const [evaluationCriteria, setEvaluationCriteria] = useState([]);
  const [note, setNote] = useState('');

  useEffect(() => {
    const inputString = task.task.description;

    // Split the string into sections
    const sections = inputString.split('Objectives:');
  
    // Get the project title
    const [title] = sections[0].split('Project Title:')[1].trim().split('\n');
    setProjectTitle(title);
  
    // Get the brief introduction
    const introduction = sections[0].split('Brief Introduction:')[1].trim();
    setBriefIntroduction(introduction);
  
    // Get the objectives
    const objectivesList = sections[1].split('Requirements/User Stories:')[0].trim().split('\n');
    const filteredObjectives = objectivesList.filter((line) => line.trim());
    setObjectives(filteredObjectives);
  
    // Get the requirements/user stories
    const requirementsList = sections[1].split('Requirements/User Stories:')[1].split('Additional Resources/Constraints:')[0].trim().split('\n');
    const filteredRequirements = requirementsList.filter((line) => line.trim());
    setRequirements(filteredRequirements);
  
    // Get the additional resources/constraints
    const resourcesList = sections[1].split('Additional Resources/Constraints:')[1].split('Evaluation Criteria:')[0].trim().split('\n');
    const filteredResources = resourcesList.filter((line) => line.trim());
    setAdditionalResources(filteredResources);
  
    // Get the evaluation criteria
    const criteriaList = sections[1].split('Evaluation Criteria:')[1].split('Note:')[0].trim().split('\n');
    const filteredCriteria = criteriaList.filter((line) => line.trim());
    setEvaluationCriteria(filteredCriteria);
  
    // Get the "Good luck" message
    const note = sections[1].split('Note:')[1].trim();
    setNote(note);
  }, [task]);


    useEffect(() => {
      const fetchData = async () => {
        const token = localStorage.getItem('accessToken');
        try {
          const response = await axios.get("http://127.0.0.1:8000/api/home/", {
            headers: {
              Authorization: `Bearer ${token}`, // Include the token in the request headers
            },
          });
          if (response.status === 403) {
            navigate('/login');
          }
          setUserData(response.data);
          
        }
        catch (error) {
          setError(error.response);
          if (error.status === 403) {
            navigate('/login');
          }
        }
      };

      fetchData();
    }, [navigate]);
  
    const formatDateTime = (dateTimeString) => {
      const date = new Date(dateTimeString);
      const year = date.getFullYear();
      const month = date.getMonth() + 1;
      const day = date.getDate();
      const hours = date.getHours();
      const minutes = date.getMinutes().toString().padStart(2, '0');
      return `${day}/${month}/${year} ${hours}:${minutes}`;
    };

    if (!userData) {
      return <div>Loading...</div>;
    }
    
    const data = userData;
  return (
    <div className="desktop-1">
      {error ? (
        <div className="error-message">
          {error}
        </div>
        ) : (
        <div className="dashboard-parent">
          <main className="dashboard">
            <section className="dashboard-child"></section>

            {/* Left Side Pannel */}
              <LeftSide Data={data} />

            {/* Top Side Pannel */}
            <TopSide />
            
            {/* Right Side Pannel */}
            <section className="main-content-wrapper">
              <div className="main-content">
                <div className="input-collector">
                  <div className="input-filter-parent">
                    {/* Task Details Component */}
                    <div className="input-filter">
                      <div className="frame-parent20">
                        <div className="frame-parent21">
                          <div className="front-end-web-developer-parent">
                          </div>                         
                            <div className="rectangle-parent24">
                            <div className="frame-child35" />
                            <div className="module-01">{task.task.title}</div>
                            <div className="deadline-10022024">
                                    Deadline: {formatDateTime(task.task.submission_deadline)}
                                  </div>
                            <div className="frame-wrapper14">
                              <div className="frame-parent22">
                                <div className="frame-parent23">
                                  <div className="duration-4-days-parent">
                                    {/* <div className="duration-4-days">Complexity: Medium</div> */}
                                    <div className="task-details-parent">
                                    </div>
                                    <h3>Project: {projectTitle}</h3>
                                    <h4>Brief Introduction:</h4>
                                    <p>{briefIntroduction}</p>
                                    <h4>Objectives:</h4>
                                    <ul>
                                      {objectives.map((objective, index) => (
                                        <li key={index}>- {objective}</li>
                                      ))}
                                    </ul>
                                    <h4>Requirements/User Stories:</h4>
                                    <ul>
                                      {requirements.map((requirement, index) => (
                                        <li key={index}>- {requirement}</li>
                                      ))}
                                    </ul>
                                    <h4>Additional Resources/Constraints:</h4>
                                    <ul>
                                      {additionalResources.map((resource, index) => (
                                        <li key={index}>- {resource}</li>
                                      ))}
                                    </ul>
                                    <h4>Evaluation Criteria:</h4>
                                    <ul>
                                      {evaluationCriteria.map((criterion, index) => (
                                        <li key={index}>- {criterion}</li>
                                      ))}
                                    </ul>
                                    <h4>Note:</h4>
                                    <p>{note}</p>
                                    {task.task.issues && (
                                      <div>
                                        <h3> Task Issues: <br /></h3>
                                        <p> {task.task.issues}</p>
                                      </div>
                                    )}
                                  </div>
                                  
                                </div>
                                {(task.task.task_completed === false) && (
                                  <NavLink to={`/internship/task-submission/${task.task.id}/`} state={{ task }}>
                                  <button className="rectangle-parent25">
                                    <div className="frame-child37" />
                                      <div className="completed">Upload</div>
                                  </button>
                                  </NavLink>
                                )}
                                {(task.task.task_completed === true) && (
                                  <button className="rectangle-parent25">
                                    <div className="frame-child37" />
                                      <div className="completed">Completed</div>
                                  </button>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </main>
        </div>
      )}
    </div>
  )
}
export default InternshipTask;

