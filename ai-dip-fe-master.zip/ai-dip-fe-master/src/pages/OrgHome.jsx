import React, { useState, useEffect } from 'react';
import { NavLink, useNavigate } from "react-router-dom";
import axios from "axios";
import OrgNavbar from '../components/OrgNavbar';
import "../style/OrgHome.css";

const OrgHome = () => {
    const [candidates, setCandidates] = useState([]);
    const [query, setQuery] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        const token = localStorage.getItem('accessToken');
        try {
            const response = await axios.get(`http://127.0.0.1:8000/api/org/?q=${query}`, {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            
            });
            if (response.status === 200) {
                setCandidates(response.data);
            }
        } catch (error) {
            if (error.status === 403) {
                navigate('/login');
            }
        }
    };

    const handleSubmit2 = async (q) => {
        const token = localStorage.getItem('accessToken');
        try {
            const response = await axios.get(`http://127.0.0.1:8000/api/org/?q=${q}`, {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            
            });
            if (response.status === 200) {
                setCandidates(response.data);
            }
        } catch (error) {
            if (error.status === 403) {
                navigate('/login');
            }
        }
    };

    useEffect(() => {
        const fetchData = async () => {
            const token = localStorage.getItem('accessToken');
            try {
                const response = await axios.get("http://127.0.0.1:8000/api/org/", {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                
                });
                if (response.status === 200) {
                    setCandidates(response.data);
                }
            } catch (error) {
                if (error.status === 403) {
                    navigate('/login');
                }
            }
        }
        fetchData();
    }, [navigate]);
    return (
        <div className='org-home'>
            <link 
                rel="stylesheet" 
                href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" 
                integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" 
                crossOrigin="anonymous"
            /> 
            <OrgNavbar />
            <div className="page-content p-5" id="content">
                <h2 className="display-4 text-white">AI Driven Internship Platform</h2>
                <form style={{marginTop: '40px'}} className="form-inline">
                    <input 
                        style={{width: '650px'}} 
                        className="form-control mr-sm-2" 
                        type="search" 
                        placeholder="Search for candidate" 
                        aria-label="Search"
                        onChange={(e) => setQuery(e.target.value)}
                    />
                    <button className="btn btn-outline-success my-2 my-sm-0" type="submit" onClick={handleSubmit}>Search</button>
                </form>
               
                <button 
                    id="sidebarCollapse" 
                    type="button" 
                    className="btn btn-light bg-white rounded-pill shadow-sm px-4 mb-4" onClick={ () => { handleSubmit2('React')}}
                    style={{marginRight: '20px', marginTop: '10px'}}
                >
                    <small className="text-uppercase font-weight-bold">React</small>
                </button>

                <button 
                    id="sidebarCollapse" 
                    type="button" 
                    className="btn btn-light bg-white rounded-pill shadow-sm px-4 mb-4" onClick={ () => { handleSubmit2('Django')}}
                    style={{marginRight: '20px', marginTop: '10px'}}
                >
                    <small className="text-uppercase font-weight-bold">Django</small>
                </button>
                
                <button 
                    id="sidebarCollapse" 
                    type="button" 
                    className="btn btn-light bg-white rounded-pill shadow-sm px-4 mb-4" onClick={ () => { handleSubmit2('Flask')}}
                    style={{marginRight: '20px', marginTop: '10px'}}
                >
                    <small className="text-uppercase font-weight-bold">Flask</small>
                </button>
                <button 
                    id="sidebarCollapse" 
                    type="button" 
                    className="btn btn-light bg-white rounded-pill shadow-sm px-4 mb-4" onClick={ () => { handleSubmit2('Python')}}
                    style={{marginRight: '20px', marginTop: '10px'}}
                >
                    <small className="text-uppercase font-weight-bold">Python</small>
                </button>
                <button 
                    id="sidebarCollapse" 
                    type="button" 
                    className="btn btn-light bg-white rounded-pill shadow-sm px-4 mb-4" onClick={ () => { handleSubmit2('SQL')}}
                    style={{marginRight: '20px', marginTop: '10px'}}
                >
                    <small className="text-uppercase font-weight-bold">SQL</small>
                </button>
                <div style={{marginTop: '-10px'}} className="separator"></div>


                <div className="row text-white">
                    <div className="col-lg">
                    
                    <h2>Candidates</h2>
                    <div>
                        {candidates.map((candidate, index) => (
                            <div key={index}>
                                <NavLink to={`/org/candidate/${candidate.id}`} state={{candidate}} style={{textDecoration: 'none'}}> 
                                <div className="frame-wrapper10" style={{width: '750px',  marginBottom: '10px'}}>
                                    <div className="rectangle-parent15" style={{backgroundColor: '#d4e8e3', borderRadius: '20px'}}>
                                    <div className="frame-parent16" style={{width: '600px'}}>
                                        <div className="wrapper2">
                                        <div className="div8">0{index + 1}</div>
                                        </div>
                                        <div className="rectangle-parent16">
                                        <div className="frame-child24" />
                                        <img
                                            className="frame-child25"
                                            loading="lazy"
                                            alt=""
                                            src={`http://127.0.0.1:8000/${candidate.profile_photo}` || '/default_profile_photo.jpg'}
                                        />
                                        </div>
                                        <div className="frame-wrapper11">
                                        <div className="frame-parent17" >
                                            <div className="david-brow-wrapper">
                                            <h2 className="david-brow" >{candidate.first_name} {candidate.last_name}</h2>
                                            </div>
                                            <div className="full-stack-developer">{candidate.category}</div>
                                        </div>
                                        </div>
                                    </div>
                                    <div className="wrapper3">
                                        <b className="b1">{candidate.skill_score || '00'}</b>
                                    </div>
                                    </div>
                                </div>
                                </NavLink>
                            </div>
                        ))}
                    </div>

                    

                    </div>
                    
                </div>

            </div>
            
        </div>
    );
};
export default OrgHome;