import React, {useEffect, useState} from 'react'
import { useLocation, useNavigate } from 'react-router-dom';
import OrgNavbar from '../components/OrgNavbar';
import "../style/SendOffer.css"
import axios from 'axios';

const SendOffer = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const { candidate } = location.state;
    const [offer, setOffer] = useState({receiver: candidate.id});
    const [user, setUser] = useState('');
    useEffect(() => {
        const fetchProfile = async () => {
            const token = localStorage.getItem('accessToken');
            try {
                const response = await axios.get("http://127.0.0.1:8000/api/org-profile/", {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setUser(response.data.id)
            }
            catch (error) {
                console.error(error.message || 'An error occurred');
            }
        }
        fetchProfile();
    }, []);
    
    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const token = localStorage.getItem('accessToken');
            const response = await axios.post('http://127.0.0.1:8000/api/offers/', {offer, user}, {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });
            if (response.status === 201) {
                alert('Offer Send Successfully')
                navigate('/org/home')
            } else if (response.status === 208) {
                alert('Offer alredy sent')
                navigate('/org/home')
            } else {
                alert('Error Occured. Please try agian later.')
                navigate('/org/home')
            }

        } catch (error) {
            if (error.response.status === 403) {
                navigate('/org/login');
            } else if (error.response) {
                alert(error.response.statusText)
            }
            console.error(error);
        }
    }
    
    const handleInputChange = (e) => {
        const {name, value} = e.target;
        setOffer({
            ...offer,
            [name]: value
        });
    }
    return(
        <div className="org-home">
            <div className="send-offer">
                <link 
                    rel="stylesheet" 
                    href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" 
                    integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" 
                    crossOrigin="anonymous"
                /> 
                <OrgNavbar />
                <div className="page-content p-5" id="content" >
                    <h1>Send Offer</h1>
                    <p>Candidate: {candidate.first_name} {candidate.last_name}</p>
                    <form method='POST' onSubmit={handleSubmit}>
                        <label htmlFor="title">Job Title</label>
                        <input type='text'name="title" placeholder='Backend Developer Intern...'onChange={handleInputChange}/>
                        <br /> <br />
                        <label htmlFor="description">Job Description</label>
                        <textarea name="description" placeholder='Roles and Responsibilities'onChange={handleInputChange}/>
                        <br />
                        <label htmlFor="location">Job Location</label>
                        <input type='text' name="location" placeholder='Address of the Office'onChange={handleInputChange}/>
                        <br />
                        <label htmlFor="salary">Estimated Salary</label>
                        <input type='text' name="salary" placeholder='Estimated Salary'onChange={handleInputChange}/>
                        <br />
                        <label htmlFor="company">Company Name</label>
                        <input type='text' name="company_name" placeholder='Name of the company'onChange={handleInputChange}/>
                        <br />
                        <button type='submit'>Send Offer</button>
                    </form>
                </div>
            </div>
        </div>
    )
};
export default SendOffer;
