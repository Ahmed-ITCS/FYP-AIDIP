import React, { useState, useEffect } from 'react';
import { NavLink, useNavigate } from "react-router-dom";
import LeftSide from "../components/LeftSide";
import TopSide from "../components/TopSide";
import "../style/index.css"
import "../style/Skills.css"
import axios from "axios";

const Skills = () => {
  const [skills, setSkills] = useState([]);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const [userData, setUserData] = useState({ profile: { first_name: "John", last_name: "Sign"}});

    useEffect(() => {
      const fetchData = async () => {
        const token = localStorage.getItem('accessToken');
        try {
          const response = await axios.get("http://127.0.0.1:8000/api/home/", {
            headers: {
              Authorization: `Bearer ${token}`, // Include the token in the request headers
            },
          });
          if (response.status === 403) {
            navigate('/login');
          }
          setUserData(response.data);
          
        }
        catch (error) {
          setError(error.response);
          if (error === undefined) {
       
          } else if (error.response !== undefined) {
            if (error.response.status === 403) {
              navigate('/login');
            }
          
          }
        }
      };

      const fetchSkills = async () => {
        try {
          const skill_response = await fetch('http://127.0.0.1:8000/api/skills/', {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${localStorage.getItem('accessToken')}` // Ensure the user is authenticated
            },
          });
  
          const data = await skill_response.json();
          setSkills(data);
        } catch (error) {
          setError(error.response);
          if (error === undefined) {
       
          } else if (error.response !== undefined) {
            if (error.response.status === 403) {
              navigate('/login');
            }
          
          }
        }
      };

      fetchData();
      fetchSkills();
    }, [navigate]);

    const data = userData;

  return (
    <div className="desktop-1">
      <div className="dashboard-parent">
        <main className="dashboard">
          <section className="dashboard-child"></section>

          {/* Left Side Panel */}
          <LeftSide Data={data}/>

          {/* Top Side Panel */}
          <TopSide />

          {/* Right Side Panel */}
          <div className="upgrade-button">
            <div className="profile-picture">
              <div className="pass-a-tech-stack-parent">
                <h2 className="pass-a-tech">Pass a Tech Stack</h2>
                <div className="frame-parent58">
                  {error && <div className="error">{error}</div>}
                  {skills.map((skill) => (
                    <div key={skill.id} className="rectangle-parent84">
                      <div className="frame-child116" />
                      <img
                        className="screenshot-2024-02-06-at-1126"
                        loading="lazy"
                        alt=""
                        src={`${skill.skill_name}.jpg`}
                      />
                      <div className="html-css-wrapper">
                        <div className="html-css">
                          <NavLink to={`/assessment-check/${skill.id}/`} state={{ skill }} style={{textDecoration: 'none'}}>
                          {skill.skill_name}
                          </NavLink>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

export default Skills;

