import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../style/Register.css';

const Register = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    try {
      await axios.post('http://127.0.0.1:8000/api/register/', {
        email: email,
        password: password,
      });

      setMessage('Verification email sent to your email address.');
      setError('');
    } catch (error) {
      if (error.response) {
        setError(error.response.data.detail || 'An error occurred during registration');
      } else {
        setError(error.message || 'An error occurred');
      }
    }
  };

  return (
    <div className="register-page">
    
      <h4 className="ai-driven-internship">AI Driven Internship Platform</h4>
      <section className="a-i-internship-platform">
      <img src="4627349.jpg" alt="logo" className="logo" style={{width: '600px'}}/>
        <div className="register-container">
          <h2 className="register-title">Register</h2>
          <form className="register-form" onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="email" className="form-label">Email</label>
              <input
                type="email"
                className="form-input"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="password" className="form-label">Password</label>
              <input
                type="password"
                className="form-input"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="confirm-password" className="form-label">Confirm Password</label>
              <input
                type="password"
                className="form-input"
                id="confirm-password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
              />
            </div>
            <button className="form-button" type="submit">Register</button>
          </form>
          {error && <div className="error-message" style={{fontSize: '15px'}}>{error}</div>}
          {message && <div className="success-message" style={{fontSize: '15px'}}>{message}</div>}
        </div>
      </section>
      <div className="login-redirect">
        <b className="login-redirect-text">
          Already have an account? <span className="login-link" onClick={() => navigate('/login')}>Login</span>
        </b>
      </div>
    </div>
  );
};

export default Register;
