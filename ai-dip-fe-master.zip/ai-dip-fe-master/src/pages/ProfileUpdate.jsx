import React, { useState, useEffect } from 'react';
import { useNavigate } from "react-router-dom";
import axios from "axios";
import LeftSide from "../components/LeftSide";
import TopSide from "../components/TopSide";
import "../style/index.css";
import "../style/Profile.css";
import "../style/ProfileUpdate.css";

const ProfileUpdate = () => {
  const [profile, setProfile] = useState({});
  const [error, setError] = useState('');
  const [userData, setUserData] = useState(null);
  const [profileData, setProfileData] = useState({});
  const [profileUserData, setProfileUserData] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      const token = localStorage.getItem('accessToken');
      try {
        const response = await axios.get("http://127.0.0.1:8000/api/home/", {
          headers: {
            Authorization: `Bearer ${token}`, // Include the token in the request headers
          },
        });
        if (response.status === 403) {
          navigate('/login');
        }
        setUserData(response.data);
      } catch (error) {
        setError(error.response);
        if (error.status === 403) {
          navigate('/login');
        }
      }
    };

    fetchData();
  }, [navigate]);

  useEffect(() => {
    const token = localStorage.getItem('accessToken');
    if (!token) {
      navigate('/login');
    }
    const fetchProfile = async () => {
      try {
        const response = await axios.get("http://127.0.0.1:8000/api/profile/", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        if (response.status === 403) {
          navigate('/login');
        }
        setProfile(response.data);
      } catch (error) {
        setError(error.response);
          if (error.status === 403) {
            navigate('/login');
          }
      }
    };

    fetchProfile();
  }, [navigate]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setProfileData({
      ...profileData,
      [name]: value,
    });
  };

  const handleInputChangeUser = (e) => {
    const { name, value } = e.target;
    setProfileUserData({
      ...profileUserData,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem('accessToken');
    try {
      const response = await axios.patch("http://127.0.0.1:8000/api/settings/", { profileUserData, profileData}, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      if (response.status === 200) {
        setProfile(response.data.profile);
        setProfileUserData(response.data.user);
        alert('Profile updated successfully');
      }
    } catch (error) {
      setError(error.response);
      if (error.status === 403) {
        navigate('/login');
      }
    }
  };

  if (!userData) {
    return <div>Loading...</div>;
  }
  console.log('profile-photo = ', profile)

  return (
    <div className="desktop-1">
      {error ? (
        <div className="error-message">
          {error}
        </div>
        ) : (
        <div className="dashboard-parent">
          <main className="dashboard">
            <section className="dashboard-child"></section>

            {/* Left Side Pannel */}
              <LeftSide Data={userData} />

            {/* Top Side Pannel */}
            <TopSide />
            
            {/* Right Side Pannel */}
            <div className="profile-settings">
              <h2 className="settings-title">Settings</h2>
              <form className="settings-form" method="post" onSubmit={handleSubmit}>
                <div className="form-group">
                  <label htmlFor="profile_photo_url">Profile Photo</label>
                  <input type="file" id="profile_photo" name="profile_photo_url" />
                </div>

                <div className="form-group">
                  <label htmlFor="username">Username</label>
                  <input
                    type="text"
                    id="username"
                    name="username"
                    defaultValue={userData.username}
                    onChange={handleInputChangeUser}
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="password">Password</label>
                  <input
                    type="password"
                    id="password"
                    name="password"
                    onChange={handleInputChangeUser}
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="first_name">First Name</label>
                  <input
                    type="text"
                    id="first_name"
                    name="first_name"
                    defaultValue={profile.first_name}
                    onChange={handleInputChange}
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="last_name">Last Name</label>
                  <input
                    type="text"
                    id="last_name"
                    name="last_name"
                    defaultValue={profile.last_name}
                    onChange={handleInputChange}
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="bio">Bio</label>
                  <input
                    type="text"
                    id="bio"
                    name="bio"
                    defaultValue={profile.bio}
                    onChange={handleInputChange}
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="phone_number">Phone Number</label>
                  <input
                    type="text"
                    id="phone_number"
                    name="phone_number"
                    defaultValue={profile.phone_number}
                    onChange={handleInputChange}
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="university_name">University Name</label>
                  <input
                    type="text"
                    id="university_name"
                    name="university_name"
                    defaultValue={profile.university_name}
                    onChange={handleInputChange}
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="department">Department</label>
                  <input
                    type="text"
                    id="department"
                    name="department"
                    defaultValue={profile.department}
                    onChange={handleInputChange}
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="degree_name">Degree Name</label>
                  <input
                    type="text"
                    id="degree_name"
                    name="degree_name"
                    defaultValue={profile.degree_name}
                    onChange={handleInputChange}
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="graduation_year">Graduation Year</label>
                  <input
                    type="text"
                    id="graduation_year"
                    name="graduation_year"
                    defaultValue={profile.graduation_year}
                    onChange={handleInputChange}
                  />
                </div>

                <button type="submit" className="save-button">Save Settings</button>
              </form>
            </div>
          </main>
        </div>
      )}
    </div>
  );
};

export default ProfileUpdate;
