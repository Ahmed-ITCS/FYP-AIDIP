import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../style/OrgRegister.css';

const OrgRegister = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    try {
      await axios.post('http://127.0.0.1:8000/api/org-register/', {
        email: email,
        password: password,
      });

      setMessage('Verification email sent to your email address.');
      setError('');
    } catch (error) {
      if (error.response) {
        setError(error.response.data.detail || 'An error occurred during registration');
      }
    }
  };

  return (
    <div className="register-wrapper">
      <div className="inner">
        <img src="/image-1.png" alt="" className="image-1"/>
        <form onSubmit={handleSubmit}>
          <h3>New Account?</h3>
          <div className="form-holder">
            <span className="lnr lnr-user"></span>
            <input 
              type="text" 
              className="form-control" 
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="form-holder">
            <span className="lnr lnr-lock"></span>
            <input 
              type="password" 
              className="form-control" 
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              />
          </div>
          <div className="form-holder">
            <span className="lnr lnr-lock"></span>
            <input 
              type="password" 
              className="form-control" 
              placeholder="Confirm Password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
            />
          </div>
          <button>
            <span>Register</span>
          </button>
          <p className="login-redirect-text" style={{marginTop: '20px', textAlign: 'center'}}>
            Already have an account? <span className="login-link" onClick={() => navigate('/org/login')}>Login</span>
          </p>
          {error && <div className="error-message" style={{fontSize: '15px', textAlign: 'center'}}>{error}</div>}
          {message && <div className="success-message" style={{fontSize: '15px', textAlign: 'center'}}>{message}</div>}
        </form>
        
        
        <img src="/image-2.png" alt="" className="image-2"/>
      </div>
    </div>
  );
};

export default OrgRegister;
